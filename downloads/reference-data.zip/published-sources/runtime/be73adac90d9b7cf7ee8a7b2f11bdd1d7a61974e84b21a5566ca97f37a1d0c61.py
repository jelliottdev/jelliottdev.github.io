"""Run bounded rune transformations locally. No code execution or network access.

Usage: python tools/research_runner.py --task task.json --out results.json
Only rune characters move/change; separators retain their exact positions.
"""
import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re

TASK_SCHEMA = 'liberpedia-local-task-v1'
RESULT_SCHEMA = 'liberpedia-local-result-v1'
ENGINE = 'rune-program-v1'
MAX_FILE_BYTES = 2_000_000
LANGUAGE_MODEL_ID = 'gp29-flores-trigram-v1'
LANGUAGE_MODEL_SHA256 = '8a5171ba8bfc5bea73e7ce7a38bca85cd99bc2175535a27e21450208dbdbaad4'
_LANGUAGE_MODEL = None


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fields(value, expected, label):
    require(isinstance(value, dict) and set(value) == set(expected),
            label + ' has invalid fields')


def integer(value, minimum, maximum):
    return type(value) is int and minimum <= value <= maximum


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def task_identity(task):
    return hashlib.sha256(canonical({k: v for k, v in task.items() if k != 'taskId'})).hexdigest()


def language_model():
    """Load only this reviewed adjacent asset, and only for its criterion."""
    global _LANGUAGE_MODEL
    if _LANGUAGE_MODEL is None:
        path = Path(__file__).with_name('language-model.json')
        with path.open('rb') as source:
            raw = source.read(MAX_FILE_BYTES + 1)
        require(len(raw) <= MAX_FILE_BYTES, 'Rune-language model exceeds its byte limit')
        data = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Invalid model number')))
        fields(data, ('payload', 'sha256'), 'Rune-language model')
        payload = data['payload']
        require(data['sha256'] == LANGUAGE_MODEL_SHA256 and
                hashlib.sha256(canonical(payload)).hexdigest() == LANGUAGE_MODEL_SHA256,
                'The pinned rune-language model changed')
        require(payload['schema'] == 'liberpedia-language-model-v1'
                and payload['modelId'] == LANGUAGE_MODEL_ID and payload['scoreVersion'] == 1
                and payload['minimumRunes'] == 40 and payload['shuffle']['replicates'] == 32
                and payload['scoring']['gramOrder'] == 3 and payload['scoring']['scale'] == 1000
                and len(payload['alphabet']) == 29 and len(payload['models']) == 8,
                'The rune-language protocol is invalid')
        for model in payload['models']:
            require(isinstance(model['id'], str) and len(model['scores']) == 29 ** 3
                    and all(integer(score, -32768, 0) for score in model['scores']),
                    'A rune-language table is invalid')
        _LANGUAGE_MODEL = payload
    return _LANGUAGE_MODEL


def language_evaluate(values):
    require(isinstance(values, list) and len(values) <= 20000
            and all(integer(value, 0, 28) for value in values), 'Invalid language-comparison rune indices')
    model = language_model()
    base = {'runes': len(values), 'windows': max(0, len(values) - 2)}
    if len(values) < model['minimumRunes']:
        return {**base, 'status': 'insufficient', 'models': []}

    def score(sequence, table):
        return sum(table[a * 841 + b * 29 + c]
                   for a, b, c in zip(sequence, sequence[1:], sequence[2:]))

    rows = [{'id': reference['id'], 'total': score(values, reference['scores']),
             'shuffledMin': None, 'shuffledMax': None, 'shuffledAtOrAbove': 0}
            for reference in model['models']]
    for replicate in range(32):
        sequence = values[:]
        state = (0x33010000 ^ (len(values) * 0x9E3779B1) ^ ((replicate + 1) * 0x85EBCA6B)) & 0xFFFFFFFF
        state = state or 1
        for position in range(len(sequence) - 1, 0, -1):
            state = (state ^ (state << 13)) & 0xFFFFFFFF
            state = (state ^ (state >> 17)) & 0xFFFFFFFF
            state = (state ^ (state << 5)) & 0xFFFFFFFF
            other = state % (position + 1)
            sequence[position], sequence[other] = sequence[other], sequence[position]
        for row, reference in zip(rows, model['models']):
            total = score(sequence, reference['scores'])
            row['shuffledMin'] = total if row['shuffledMin'] is None else min(row['shuffledMin'], total)
            row['shuffledMax'] = total if row['shuffledMax'] is None else max(row['shuffledMax'], total)
            row['shuffledAtOrAbove'] += total >= row['total']
    return {**base, 'status': 'compared', 'models': rows}


def validate(task):
    fields(task, ('schema', 'engine', 'taskId', 'title', 'pages', 'alphabet', 'steps', 'criterion'), 'Task')
    require(task['schema'] == TASK_SCHEMA and task['engine'] == ENGINE, 'Unsupported schema or engine')
    require(isinstance(task['taskId'], str) and re.fullmatch('[0-9a-f]{64}', task['taskId']), 'Invalid taskId')
    require(isinstance(task['title'], str) and task['title'].strip() and len(task['title']) <= 300, 'Invalid title')
    alphabet = task['alphabet']
    require(isinstance(alphabet, list) and len(alphabet) == 29, 'Alphabet must contain exactly 29 entries')
    runes = set()
    for entry in alphabet:
        fields(entry, ('rune', 'latin', 'prime'), 'Alphabet entry')
        rune = entry['rune']
        require(isinstance(rune, str) and len(rune) == 1 and not rune.isspace()
                and not 0xD800 <= ord(rune) <= 0xDFFF and rune not in runes, 'Invalid or duplicate rune')
        require(isinstance(entry['latin'], str) and 1 <= len(entry['latin']) <= 8, 'Invalid Latin label')
        require(integer(entry['prime'], 2, 1000000), 'Invalid prime value')
        runes.add(rune)
    pages = task['pages']
    require(isinstance(pages, list) and 1 <= len(pages) <= 75, 'Task needs 1–75 pages')
    seen, count, total_text = set(), 0, 0
    for page in pages:
        fields(page, ('id', 'text'), 'Page')
        identifier = page['id']
        require(isinstance(identifier, str) and re.fullmatch(r'lp[12]-[0-9]{2}', identifier)
                and identifier not in seen, 'Invalid or duplicate page ID')
        require(int(identifier[4:]) <= (16 if identifier[2] == '1' else 57), 'Page ID outside manuscript bounds')
        seen.add(identifier)
        require(isinstance(page['text'], str), 'Page text must be a string')
        total_text += len(page['text'])
        count += sum(ch in runes for ch in page['text'])
    require(count <= 20000, 'Task exceeds 20000 runes')
    require(total_text <= 300000, 'Task exceeds 300000 text codepoints')
    steps = task['steps']
    require(isinstance(steps, list) and len(steps) <= 8, 'Task exceeds 8 steps')
    for step in steps:
        require(isinstance(step, dict), 'Step must be an object')
        if step.get('op') == 'reverse':
            fields(step, ('op', 'unit'), 'Reverse step')
            require(step['unit'] in ('line', 'word', 'page'), 'Invalid reverse unit')
        elif step.get('op') == 'affine':
            fields(step, ('op', 'a', 'b'), 'Affine step')
            require(integer(step['a'], 0, 28) and integer(step['b'], 0, 28), 'Invalid affine coefficients')
        elif step.get('op') == 'keyed-shift':
            fields(step, ('op', 'key', 'mode', 'direction', 'reset'), 'Keyed-shift step')
            require(isinstance(step['key'], list) and 1 <= len(step['key']) <= 256
                    and all(integer(value, 0, 28) for value in step['key']), 'Invalid key indices')
            require(step['mode'] in ('repeat', 'plaintext-autokey', 'ciphertext-autokey'), 'Invalid key mode')
            require(step['direction'] in ('subtract', 'add'), 'Invalid key direction')
            require(step['reset'] in ('page', 'line', 'word'), 'Invalid key reset')
        elif step.get('op') == 'interrupted-keyed-shift':
            fields(step, ('op', 'key', 'direction', 'reset', 'interrupts'), 'Interrupted-keyed step')
            require(isinstance(step['key'], list) and 1 <= len(step['key']) <= 256
                    and all(integer(value, 0, 28) for value in step['key']), 'Invalid interrupted key indices')
            require(step['direction'] in ('subtract', 'add'), 'Invalid interrupted key direction')
            require(step['reset'] in ('page', 'line', 'word'), 'Invalid interrupted key reset')
            require(isinstance(step['interrupts'], list) and 1 <= len(step['interrupts']) <= 29
                    and all(integer(value, 0, 28) for value in step['interrupts'])
                    and step['interrupts'] == sorted(set(step['interrupts'])), 'Interrupt indices must be unique and sorted')
        elif step.get('op') == 'finite-shift':
            fields(step, ('op', 'key', 'direction', 'reset'), 'Finite-shift step')
            require(isinstance(step['key'], list) and 1 <= len(step['key']) <= 20000
                    and all(integer(value, 0, 28) for value in step['key']), 'Invalid finite key indices')
            require(step['direction'] in ('subtract', 'add'), 'Invalid finite key direction')
            require(step['reset'] in ('page', 'line', 'word'), 'Invalid finite key reset')
            # All supported transforms preserve the rune/separator geometry.
            # Check every segment before any transformation can produce output.
            for page in pages:
                position = 0
                for character in page['text']:
                    if character in runes:
                        position += 1
                        require(position <= len(step['key']),
                                'Finite key stream underrun on ' + page['id'])
                    elif boundary(character, step['reset'], runes):
                        position = 0
        elif step.get('op') == 'cumulative-difference':
            fields(step, ('op', 'reset'), 'Cumulative step')
            require(step['reset'] in ('page', 'line', 'word'), 'Invalid cumulative reset')
        else:
            raise ValueError('Unsupported operation')
    criterion = task['criterion']
    require(isinstance(criterion, dict), 'Criterion must be an object')
    if criterion.get('kind') == 'exact-prefix':
        fields(criterion, ('kind', 'values'), 'Prefix criterion')
        require(isinstance(criterion['values'], list) and 1 <= len(criterion['values']) <= 256
                and all(integer(v, 0, 28) for v in criterion['values']), 'Invalid prefix values')
    elif criterion.get('kind') == 'word-prime-sums':
        fields(criterion, ('kind', 'table', 'boundaries'), 'Word-prime-sums criterion')
        require(criterion['table'] in ('canonical', 'reversed'), 'Invalid prime table')
        require(criterion['boundaries'] in ('non-rune', 'hyphen-period'), 'Invalid word boundary rule')
    elif criterion.get('kind') == 'word-affine-count':
        fields(criterion, ('kind', 'lag', 'a', 'b', 'boundaries'), 'Word-pair criterion')
        require(integer(criterion['lag'], 1, 12) and integer(criterion['a'], 0, 28)
                and integer(criterion['b'], 0, 28), 'Invalid word-pair parameters')
        require(criterion['boundaries'] in ('non-rune', 'hyphen-period'), 'Invalid word boundary rule')
        opportunities = sum(max(0, len(word) - criterion['lag']) for page in pages
                            for word in measurement_words(page['text'], runes, criterion['boundaries']))
        require(opportunities <= 2_000_000, 'Word-pair measurement exceeds its work limit')
    elif criterion.get('kind') == 'language-score':
        fields(criterion, ('kind', 'modelId', 'modelSha256'), 'Rune-language criterion')
        require(criterion['modelId'] == LANGUAGE_MODEL_ID and criterion['modelSha256'] == LANGUAGE_MODEL_SHA256,
                'Choose the pinned rune-language comparison criterion')
        require([entry['latin'] for entry in alphabet] == language_model()['alphabet'],
                'Rune-language comparison needs the canonical GP29 alphabet order')
    else:
        fields(criterion, ('kind',), 'Measurement criterion')
        require(criterion['kind'] == 'measurement', 'Unsupported criterion')
    require(task['taskId'] == task_identity(task), 'Task identity does not match its contents')
    require(len(canonical(task)) <= MAX_FILE_BYTES, 'Task exceeds byte limit')
    return task


def boundary(character, unit, indices):
    return (unit == 'word' and character not in indices) or (unit == 'line' and character in '\r\n')


def transform(text, step, runes, indices):
    chars = list(text)
    if step['op'] == 'reverse':
        positions = []

        def flush():
            values = [chars[i] for i in positions][::-1]
            for i, value in zip(positions, values):
                chars[i] = value
            positions.clear()

        for i, ch in enumerate(chars):
            if boundary(ch, step['unit'], indices):
                flush()
            elif ch in indices:
                positions.append(i)
        flush()
    elif step['op'] == 'interrupted-keyed-shift':
        position = 0
        interrupts = set(step['interrupts'])
        sign = -1 if step['direction'] == 'subtract' else 1
        for i, character in enumerate(chars):
            if character not in indices:
                if boundary(character, step['reset'], indices):
                    position = 0
                continue
            value = indices[character]
            if value in interrupts:
                continue
            chars[i] = runes[(value + sign * step['key'][position % len(step['key'])]) % 29]
            position += 1
    elif step['op'] == 'finite-shift':
        position = 0
        sign = -1 if step['direction'] == 'subtract' else 1
        for i, character in enumerate(chars):
            if character not in indices:
                if boundary(character, step['reset'], indices):
                    position = 0
                continue
            chars[i] = runes[(indices[character] + sign * step['key'][position]) % 29]
            position += 1
    elif step['op'] == 'keyed-shift':
        # Histories belong to this step's current reset segment, not to the
        # original program input or a preceding page. Separators never consume.
        ciphertext, plaintext = [], []
        key, mode = step['key'], step['mode']
        sign = -1 if step['direction'] == 'subtract' else 1
        for i, character in enumerate(chars):
            if character not in indices:
                if boundary(character, step['reset'], indices):
                    ciphertext.clear()
                    plaintext.clear()
                continue
            value = indices[character]
            position = len(ciphertext)
            if mode == 'repeat':
                amount = key[position % len(key)]
            elif position < len(key):
                amount = key[position]
            elif mode == 'plaintext-autokey':
                amount = plaintext[position - len(key)]
            else:
                amount = ciphertext[position - len(key)]
            decoded = (value + sign * amount) % 29
            ciphertext.append(value)
            plaintext.append(decoded)
            chars[i] = runes[decoded]
    else:
        total = 0
        for i, ch in enumerate(chars):
            if ch in indices:
                if step['op'] == 'affine':
                    value = (step['a'] * indices[ch] + step['b']) % 29
                else:
                    value = (indices[ch] - total) % 29
                    total = (total + value) % 29
                chars[i] = runes[value]
            elif step['op'] == 'cumulative-difference' and boundary(ch, step['reset'], indices):
                total = 0
    return ''.join(chars)


def measurement_words(text, indices, boundaries):
    word = []
    for character in text:
        if character in indices:
            word.append(character)
        elif boundaries == 'non-rune' or character in '-.':
            if word:
                yield word
            word = []
    if word:
        yield word


def rational_json(value):
    return {'numerator': str(value.numerator), 'denominator': str(value.denominator)}


def count_word_pairs(text, indices, criterion):
    opportunities = matches = 0
    expected = Fraction(0)
    lag, a, b = criterion['lag'], criterion['a'], criterion['b']
    for characters in measurement_words(text, indices, criterion['boundaries']):
        word = [indices[ch] for ch in characters]
        n = len(word)
        k = max(0, n - lag)
        if not k:
            continue
        opportunities += k
        matches += sum(word[i + lag] == (a * word[i] + b) % 29 for i in range(k))
        counts = Counter(word)
        ordered = sum(counts[i] * (counts[(a * i + b) % 29] - (i == (a * i + b) % 29))
                      for i in range(29))
        expected += Fraction(k * ordered, n * (n - 1))
    return opportunities, matches, expected


def run(task):
    validate(task)
    runes = [entry['rune'] for entry in task['alphabet']]
    indices = {rune: i for i, rune in enumerate(runes)}
    transformed, matches, counts = [], [], Counter()
    pairs = equal = total = 0
    word_pages = []
    word_opportunities = word_matches = 0
    word_expected = Fraction(0)
    sum_pages = []
    language_pages = []
    sum_words = sum_total = 0
    for page in task['pages']:
        text = page['text']
        for step in task['steps']:
            text = transform(text, step, runes, indices)
        values = [indices[ch] for ch in text if ch in indices]
        counts.update(values)
        total += len(values)
        pairs += max(0, len(values) - 1)
        equal += sum(a == b for a, b in zip(values, values[1:]))
        transformed.append({'page': page['id'], 'text': text})
        if task['criterion']['kind'] == 'exact-prefix':
            prefix = task['criterion']['values']
            matches.append({'page': page['id'], 'matched': values[:len(prefix)] == prefix})
        if task['criterion']['kind'] == 'language-score':
            language_pages.append({'page': page['id'], **language_evaluate(values)})
        if task['criterion']['kind'] == 'word-affine-count':
            opportunities, matched, expected = count_word_pairs(text, indices, task['criterion'])
            word_pages.append({'page': page['id'], 'opportunities': opportunities,
                               'matches': matched, 'expected': rational_json(expected)})
            word_opportunities += opportunities
            word_matches += matched
            word_expected += expected
        if task['criterion']['kind'] == 'word-prime-sums':
            words = []
            for characters in measurement_words(text, indices, task['criterion']['boundaries']):
                amount = sum(task['alphabet'][28 - indices[ch] if task['criterion']['table'] == 'reversed'
                                              else indices[ch]]['prime'] for ch in characters)
                words.append({'runes': ''.join(characters), 'sum': amount})
                sum_words += 1
                sum_total += amount
            sum_pages.append({'page': page['id'], 'words': words})
    result = {'schema': RESULT_SCHEMA, 'taskId': task['taskId'], 'engine': ENGINE,
            'metrics': {'pages': len(task['pages']), 'runes': total, 'adjacentPairs': pairs,
                        'equalAdjacentPairs': equal,
                        'ioc': sum(n * (n - 1) for n in counts.values()) / (total * (total - 1)) if total > 1 else 0.0},
            'matches': matches, 'transformed': transformed, 'runnerVersion': '1'}
    if task['criterion']['kind'] == 'word-affine-count':
        result['wordPairs'] = {'opportunities': word_opportunities, 'matches': word_matches,
                               'expected': rational_json(word_expected), 'pages': word_pages}
    if task['criterion']['kind'] == 'word-prime-sums':
        result['wordSums'] = {'words': sum_words, 'total': sum_total, 'pages': sum_pages}
    if task['criterion']['kind'] == 'language-score':
        result['languageScore'] = {'modelId': task['criterion']['modelId'],
                                   'modelSha256': task['criterion']['modelSha256'], 'pages': language_pages}
    return result


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON field: ' + key)
        result[key] = value
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    try:
        task_path, output = args.task.resolve(), args.out.resolve()
        require(output not in (task_path, Path(__file__).resolve()), 'Output cannot overwrite task or runner')
        require(not args.out.exists() and not args.out.is_symlink(), 'Output already exists')
        with task_path.open('rb') as handle:
            raw = handle.read(MAX_FILE_BYTES + 1)
        require(len(raw) <= MAX_FILE_BYTES, 'Task exceeds byte limit')
        task = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Invalid JSON constant')))
        result = run(task)
        payload = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n'
        # Exclusive creation also protects against a concurrent file appearing.
        with output.open('x', encoding='utf-8', newline='\n') as handle:
            handle.write(payload)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        parser.exit(2, 'research_runner: ' + str(error) + '\n')


if __name__ == '__main__':
    main()
