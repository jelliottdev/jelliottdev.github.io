/* Round 28 / L4 -- grind28.c -- the unswept-generator engine, derived from grind27.c
 * (R27 P1: the V1/V2/V3/K4-validated architecture) with NEW generators and a
 * STRUCTURAL per-cell gate. grind27's sources are untouched; separate binary.
 *
 * New generators (all |delta|=0-validated against on-box references via gen28.py:
 * /usr/bin/php 8.5.4 both engine modes, resident glibc -- receipts/genval.json):
 *   php_mt_scale / php_mt_mod    PHP mt_rand, canonical MT_RAND_MT19937 twist,
 *                                seeded php_mt_initialize(w)=init_genrand(w),
 *                                output temper>>1 (31-bit), reduced by
 *                                RAND_RANGE_BADSCALING(0,28) or %29
 *   php_php_scale / php_php_mod  same, but the documented pre-7.1 MT_RAND_PHP
 *                                broken twist (mask from loBit(u), not loBit(v))
 *   glibc_mod                    glibc srandom/random TYPE_3 additive (x^31+x^3+1,
 *                                int32 Schrage chain, 310-discard), out>>1 %29 --
 *                                the R19-G3-CORRECTION gen=0 open row; measured
 *                                rand()==random(), so one sweep covers both paths
 * plus grind27's four Py2.7-MT reducers (random29/grb5_mod/grb5_rej/shuffle29)
 * for the R27 S3 offset cells.
 *
 * STRUCTURAL GATE (PREREG Q1): every plan lane must name a "gate" file
 * (gates/cellgate_<lane>.dat, built by make_gates.py from the Python reference
 * pipeline). At launch, BEFORE any lane's null counts, the engine re-runs that
 * cell's (a) 64-vector parity (ks128 |delta|=0 + decode artifact parity), (b)
 * planted-control screen (the plant MUST be flagged, pmax exact), (c) false-reject
 * set (every wrong seed matched and below the cell claim bar). A lane whose gate
 * is missing or failing DOES NOT SWEEP -- no env-var override exists.
 *
 * Everything else -- beam decode, panel-max scoring, candidate/claim bars,
 * checkpointing, histograms, top-1024, append-only candidates.jsonl,
 * HIT-CANDIDATE FLAGGED-FOR-ORACLE semantics -- is grind27 code verbatim. This
 * engine makes NO hit decision; Python (hitfn20 + oracle) adjudicates candidates.
 *
 * Build (BUILD.md):
 *   gcc -O3 -march=native -fopenmp -std=gnu17 -ffp-contract=off -o grind28 grind28.c -lm
 *
 * Modes:
 *   ./grind28 --self-test                          grind27 V1+V2 (engine-health anchor)
 *   ./grind28 --gate-check gates/cellgate_X.dat    one cell's (a)+(b)+(c) gate
 *   ./grind28 --bench N --reducer R --relation X   calibration throughput
 *   ./grind28 --plan queued_cells.json --run-dir D checkpointed sweep-plan runner
 *   ./grind28 --status --run-dir D                 print STATUS.json (no worker contact)
 */
#define _GNU_SOURCE
#include <math.h>
#include <omp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* ------------------------------------------------------------------ constants */
#define NRUNE 29
#define LSCREEN 120
#define BEAMW 64
#define KS_LEN 784                 /* L_SCREEN*6 + 64 post-reducer runes */
#define MAXCH (BEAMW * 9)          /* children upper bound per step */
#define NREG 9
#define NTRI 24389                 /* 29^3 */
#define QSZ 456976                 /* 26^4 */
#define HIST_BINS 2600             /* pmax histogram: 0.01 bins over [0,26) */
#define TOPK 1024
#define CKPT_EVERY 30.0
#define MAX_WORKERS 32
#define MAX_LANES 64
#define MAX_HITS 4096

static const char *TRANS[NRUNE] = {
    "F","U","TH","O","R","C","G","W","H","N","I","J","EO","P","X","S","T",
    "B","E","M","L","NG","OE","D","A","AE","Y","IA","EA"};

/* ------------------------------------------------------------------ MT19937 (CPython 2.7 verbatim) */
typedef struct { uint32_t mt[624]; int idx; } MT;

static void mt_init_genrand(MT *r, uint32_t s) {
    r->mt[0] = s;
    for (int i = 1; i < 624; i++)
        r->mt[i] = 1812433253u * (r->mt[i-1] ^ (r->mt[i-1] >> 30)) + (uint32_t)i;
    r->idx = 624;
}

/* init_by_array([w]) -- runner.word_stream: [w] if w else [0] (identical at w=0) */
static void mt_init_word(MT *r, uint32_t w) {
    mt_init_genrand(r, 19650218u);
    uint32_t *mt = r->mt;
    int i = 1;                                  /* klen == 1, j stays 0 */
    for (int k = 624; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525u)) + w; /* + key[0] + j(=0) */
        i++;
        if (i >= 624) { mt[0] = mt[623]; i = 1; }
    }
    for (int k = 623; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941u)) - (uint32_t)i;
        i++;
        if (i >= 624) { mt[0] = mt[623]; i = 1; }
    }
    mt[0] = 0x80000000u;
    r->idx = 624;
}

static inline uint32_t mt_u32(MT *r) {
    uint32_t y;
    if (r->idx >= 624) {
        uint32_t *mt = r->mt;
        for (int kk = 0; kk < 227; kk++) {
            y = (mt[kk] & 0x80000000u) | (mt[kk+1] & 0x7FFFFFFFu);
            mt[kk] = mt[kk+397] ^ (y >> 1) ^ ((y & 1u) ? 0x9908B0DFu : 0u);
        }
        for (int kk = 227; kk < 623; kk++) {
            y = (mt[kk] & 0x80000000u) | (mt[kk+1] & 0x7FFFFFFFu);
            mt[kk] = mt[kk-227] ^ (y >> 1) ^ ((y & 1u) ? 0x9908B0DFu : 0u);
        }
        y = (mt[623] & 0x80000000u) | (mt[0] & 0x7FFFFFFFu);
        mt[623] = mt[396] ^ (y >> 1) ^ ((y & 1u) ? 0x9908B0DFu : 0u);
        r->idx = 0;
    }
    y = r->mt[r->idx++];
    y ^= y >> 11;
    y ^= (y << 7)  & 0x9D2C5680u;
    y ^= (y << 15) & 0xEFC60000u;
    y ^= y >> 18;
    return y;
}

/* genrand_res53 -- bit-exact double (a*2^26+b are exact integer doubles; any FMA
 * contraction is value-identical, and we build with -ffp-contract=off anyway). */
static inline double mt_random(MT *r) {
    uint32_t a = mt_u32(r) >> 5, b = mt_u32(r) >> 6;
    return (a * 67108864.0 + b) * (1.0 / 9007199254740992.0);
}

/* ------------------------------------------------------------------ PHP MT19937
 * php-src ext/random mt19937 engine, both modes, |delta|=0 vs /usr/bin/php 8.5.4
 * (ref_php.php / receipts/genval.json). Seeding = init_genrand(seed) exactly. */
typedef struct { uint32_t st[624]; int cnt, php_mode; } PhpMT;

#define PHP_MIX(u, v) (((u) & 0x80000000u) | ((v) & 0x7FFFFFFFu))
/* canonical: xor-mask selected by low bit of v (== mt19937ar / grind27) */
#define PHP_TWIST(m, u, v)  ((m) ^ (PHP_MIX(u, v) >> 1) ^ (((v) & 1u) ? 0x9908B0DFu : 0u))
/* MT_RAND_PHP: mask selected by low bit of u -- the documented pre-7.1 bug */
#define PHP_TWISTP(m, u, v) ((m) ^ (PHP_MIX(u, v) >> 1) ^ (((u) & 1u) ? 0x9908B0DFu : 0u))

static void php_init(PhpMT *g, uint32_t seed, int php_mode) {
    g->st[0] = seed;
    for (int i = 1; i < 624; i++)
        g->st[i] = 1812433253u * (g->st[i-1] ^ (g->st[i-1] >> 30)) + (uint32_t)i;
    g->cnt = 624;
    g->php_mode = php_mode;
}

static void php_reload(PhpMT *g) {
    uint32_t *s = g->st;
    if (!g->php_mode) {
        for (int p = 0; p < 227; p++)   s[p] = PHP_TWIST(s[p+397], s[p], s[p+1]);
        for (int p = 227; p < 623; p++) s[p] = PHP_TWIST(s[p-227], s[p], s[p+1]);
        s[623] = PHP_TWIST(s[396], s[623], s[0]);
    } else {
        for (int p = 0; p < 227; p++)   s[p] = PHP_TWISTP(s[p+397], s[p], s[p+1]);
        for (int p = 227; p < 623; p++) s[p] = PHP_TWISTP(s[p-227], s[p], s[p+1]);
        s[623] = PHP_TWISTP(s[396], s[623], s[0]);
    }
    g->cnt = 0;
}

static inline uint32_t php_rand31(PhpMT *g) {       /* mt_rand() = temper >> 1 */
    if (g->cnt >= 624) php_reload(g);
    uint32_t y = g->st[g->cnt++];
    y ^= y >> 11;
    y ^= (y << 7)  & 0x9D2C5680u;
    y ^= (y << 15) & 0xEFC60000u;
    y ^= y >> 18;
    return y >> 1;
}

/* RAND_RANGE_BADSCALING(r, 0, 28, 0x7FFFFFFF): exact PHP double arithmetic
 * (min + (long)((double)(max-min+1.0) * (r / (tmax+1.0)))). 2^31 is a power of
 * two, so the division is exact; verified value-identical to PHP's evaluation. */
static inline uint8_t php_badscale(uint32_t r31) {
    return (uint8_t)(int)(29.0 * ((double)r31 / 2147483648.0));
}

/* ------------------------------------------------------------------ glibc random()
 * TYPE_3 additive feedback (deg 31, sep 3), int32 Schrage seeding chain, 310
 * discards precomputed additively. |delta|=0 vs the RESIDENT glibc incl. seeds
 * >= 2^31 (the unsigned-long seeding reading was tried and REJECTED by the same
 * probes -- receipts/genval.json). glibc: seed 0 -> 1; rand() == random(). */
typedef struct { uint32_t ring[31]; int p; } GlibcR;

static void glibc_init(GlibcR *g, uint32_t seed) {
    if (seed == 0) seed = 1;
    int32_t r[344];
    int64_t word = (int32_t)seed;                   /* int32: negative for >= 2^31 */
    r[0] = (int32_t)seed;
    for (int i = 1; i < 31; i++) {
        int64_t hi = word / 127773, lo = word % 127773;   /* C truncating division */
        word = 16807 * lo - 2836 * hi;
        if (word < 0) word += 2147483647;
        r[i] = (int32_t)word;
    }
    for (int i = 31; i < 34; i++)  r[i] = r[i-31];
    for (int i = 34; i < 344; i++) r[i] = (int32_t)((uint32_t)r[i-31] + (uint32_t)r[i-3]);
    for (int i = 0; i < 31; i++)   g->ring[i] = (uint32_t)r[313 + i];
    g->p = 0;
}

static inline uint32_t glibc_next31(GlibcR *g) {
    int p = g->p;
    uint32_t v = g->ring[p] + g->ring[(p + 28) % 31];
    g->ring[p] = v;
    g->p = (p + 1) % 31;
    return v >> 1;
}

/* ------------------------------------------------------------------ reducers
 * (gen_py27.REDUCERS for the Py2.7-MT family + the L4 generator cells) */
enum { RED_RANDOM29, RED_GRB5_MOD, RED_GRB5_REJ, RED_SHUFFLE29,
       RED_PHP_MT_SCALE, RED_PHP_MT_MOD, RED_PHP_PHP_SCALE, RED_PHP_PHP_MOD,
       RED_GLIBC_MOD };

static int reducer_from_name(const char *s) {
    if (!strcmp(s, "random29"))      return RED_RANDOM29;
    if (!strcmp(s, "grb5_mod"))      return RED_GRB5_MOD;
    if (!strcmp(s, "grb5_rej"))      return RED_GRB5_REJ;
    if (!strcmp(s, "shuffle29"))     return RED_SHUFFLE29;
    if (!strcmp(s, "php_mt_scale"))  return RED_PHP_MT_SCALE;
    if (!strcmp(s, "php_mt_mod"))    return RED_PHP_MT_MOD;
    if (!strcmp(s, "php_php_scale")) return RED_PHP_PHP_SCALE;
    if (!strcmp(s, "php_php_mod"))   return RED_PHP_PHP_MOD;
    if (!strcmp(s, "glibc_mod"))     return RED_GLIBC_MOD;
    return -1;
}

static void reduce_stream(MT *r, int reducer, uint8_t *ks, int n) {
    switch (reducer) {
    case RED_RANDOM29:
        for (int i = 0; i < n; i++) ks[i] = (uint8_t)(int)(mt_random(r) * 29.0);
        break;
    case RED_GRB5_MOD:                      /* getrandbits(5) % 29 */
        for (int i = 0; i < n; i++) ks[i] = (uint8_t)((mt_u32(r) >> 27) % 29u);
        break;
    case RED_GRB5_REJ:                      /* getrandbits(5), reject 29..31 */
        for (int i = 0; i < n; ) {
            uint32_t v = mt_u32(r) >> 27;
            if (v < 29u) ks[i++] = (uint8_t)v;
        }
        break;
    case RED_SHUFFLE29: {                   /* repeated Fisher-Yates over range(29) */
        int got = 0;
        uint8_t pool[NRUNE];
        while (got < n) {
            for (int i = 0; i < NRUNE; i++) pool[i] = (uint8_t)i;
            for (int i = NRUNE - 1; i > 0; i--) {
                int j = (int)(mt_random(r) * (double)(i + 1));
                uint8_t t = pool[i]; pool[i] = pool[j]; pool[j] = t;
            }
            for (int i = 0; i < NRUNE && got < n; i++) ks[got++] = pool[i];
        }
        break; }
    }
}

/* ------------------------------------------------------------------ global model data */
static double  QTAB[QSZ];               /* quadgram log10 table, A..Z^4, default floor */
static float  *LMT;                     /* (24389, 9) transposed panel gather table */
static double  MU[NREG], SD[NREG];
static int     C_SCREEN[LSCREEN];
static double  G_CAND_BAR = 5.0, G_CLAIM_PAIR = 0.0, G_CLAIM_EXACT = 0.0;
static char    G_QGRAM_PATH[1024], G_PANEL_PATH[1024], G_PANEL_SHA[80];
static long    G_QGRAM_TOTAL = 0;
static double  G_QGRAM_FLOOR = 0.0;

/* reference vectors */
typedef struct {
    uint32_t seed; double pmax, beam_score;
    int ptr_end, n_skips, nchars;
    uint8_t ks128[128]; uint8_t plain[LSCREEN];
} Vec;
static Vec  G_VEC[128]; static int G_NVEC = 0;
static int  G_PLANT_SEED; static double G_PLANT_PMAX;
static int  G_PLANT_CIPHER[LSCREEN]; static uint8_t G_PLANT_PLAIN[LSCREEN];

/* translit char codes */
static uint8_t TC0[NRUNE], TC1[NRUNE], TL[NRUNE];

/* mod29 lookup for x in [-29, 57] */
static uint8_t M29[128];
#define MOD29(x) (M29[(x) + 29])

static void init_tables(void) {
    for (int i = 0; i < NRUNE; i++) {
        TL[i]  = (uint8_t)strlen(TRANS[i]);
        TC0[i] = (uint8_t)(TRANS[i][0] - 'A');
        TC1[i] = (uint8_t)(TL[i] > 1 ? TRANS[i][1] - 'A' : 0);
    }
    for (int x = -29; x <= 57; x++) M29[x + 29] = (uint8_t)(((x % 29) + 29) % 29);
}

/* ------------------------------------------------------------------ model loading */
static void die(const char *msg) { fprintf(stderr, "FATAL: %s\n", msg); exit(1); }

static void load_quadgrams(void) {
    FILE *f = fopen(G_QGRAM_PATH, "r");
    if (!f) die("cannot open quadgram file (QGRAM_PATH in engine.dat)");
    /* pass 1+2 in one go: store counts, then log-normalise (lp/score.py order) */
    static int32_t idxs[90000]; static long cnts[90000];
    int n = 0; long total = 0;
    char q[16]; long c;
    while (fscanf(f, "%15s %ld", q, &c) == 2) {
        if (strlen(q) != 4) die("bad quadgram line");
        int idx = 0;
        for (int i = 0; i < 4; i++) {
            if (q[i] < 'A' || q[i] > 'Z') die("non A-Z quadgram");
            idx = idx * 26 + (q[i] - 'A');
        }
        if (n >= 90000) die("too many quadgram entries");
        idxs[n] = idx; cnts[n] = c; n++; total += c;
    }
    fclose(f);
    if (total != G_QGRAM_TOTAL) die("quadgram total mismatch vs engine.dat");
    double logtotal = log10((double)total);
    double floorv = log10(0.01) - logtotal;
    if (fabs(floorv - G_QGRAM_FLOOR) > 1e-12) die("quadgram floor mismatch vs engine.dat");
    for (int i = 0; i < QSZ; i++) QTAB[i] = floorv;
    for (int i = 0; i < n; i++) QTAB[idxs[i]] = log10((double)cnts[i]) - logtotal;
}

static void load_panel(void) {
    FILE *f = fopen(G_PANEL_PATH, "rb");
    if (!f) die("cannot open panel_lm.f32 (run export_data.py)");
    static float lmf[NREG * NTRI];
    if (fread(lmf, sizeof(float), NREG * NTRI, f) != NREG * NTRI)
        die("panel_lm.f32 short read (expect 9*24389 float32)");
    fclose(f);
    LMT = malloc(sizeof(float) * NTRI * NREG);
    if (!LMT) die("oom");
    for (int t = 0; t < NTRI; t++)
        for (int r = 0; r < NREG; r++)
            LMT[t * NREG + r] = lmf[r * NTRI + t];
}

static void load_engine_dat(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) die("cannot open engine.dat (run export_data.py first)");
    char key[64];
    char line[8192];
    int nvec_expected = -1;
    if (fscanf(f, "%63s %63s", key, line) != 2 || strcmp(key, "GRIND27DATA"))
        die("bad engine.dat header");
    while (fscanf(f, "%63s", key) == 1) {
        if (!strcmp(key, "PANEL_SHA256")) { if (fscanf(f, "%79s", G_PANEL_SHA) != 1) die("dat"); }
        else if (!strcmp(key, "PANEL_PATH")) { if (fscanf(f, "%1023s", G_PANEL_PATH) != 1) die("dat"); }
        else if (!strcmp(key, "QGRAM_PATH")) { if (fscanf(f, "%1023s", G_QGRAM_PATH) != 1) die("dat"); }
        else if (!strcmp(key, "QGRAM_TOTAL")) { if (fscanf(f, "%ld", &G_QGRAM_TOTAL) != 1) die("dat"); }
        else if (!strcmp(key, "QGRAM_FLOOR")) { if (fscanf(f, "%lf", &G_QGRAM_FLOOR) != 1) die("dat"); }
        else if (!strcmp(key, "QGRAM_NENTRIES")) { long x; if (fscanf(f, "%ld", &x) != 1) die("dat"); }
        else if (!strcmp(key, "NREG")) { int x; if (fscanf(f, "%d", &x) != 1 || x != NREG) die("NREG != 9"); }
        else if (!strcmp(key, "MU")) { for (int i = 0; i < NREG; i++) if (fscanf(f, "%lf", &MU[i]) != 1) die("MU"); }
        else if (!strcmp(key, "SD")) { for (int i = 0; i < NREG; i++) if (fscanf(f, "%lf", &SD[i]) != 1) die("SD"); }
        else if (!strcmp(key, "CAND_BAR")) { if (fscanf(f, "%lf", &G_CAND_BAR) != 1) die("dat"); }
        else if (!strcmp(key, "CLAIM_BAR_PAIR")) { if (fscanf(f, "%lf", &G_CLAIM_PAIR) != 1) die("dat"); }
        else if (!strcmp(key, "CLAIM_BAR_EXACT")) { if (fscanf(f, "%lf", &G_CLAIM_EXACT) != 1) die("dat"); }
        else if (!strcmp(key, "CSCREEN")) {
            int n; if (fscanf(f, "%d", &n) != 1 || n != LSCREEN) die("CSCREEN len");
            for (int i = 0; i < n; i++) if (fscanf(f, "%d", &C_SCREEN[i]) != 1) die("CSCREEN");
        }
        else if (!strcmp(key, "PLANT_SEED")) { if (fscanf(f, "%d", &G_PLANT_SEED) != 1) die("dat"); }
        else if (!strcmp(key, "PLANT_PMAX")) { if (fscanf(f, "%lf", &G_PLANT_PMAX) != 1) die("dat"); }
        else if (!strcmp(key, "PLANT_CIPHER")) {
            int n; if (fscanf(f, "%d", &n) != 1 || n != LSCREEN) die("PLANT_CIPHER len");
            for (int i = 0; i < n; i++) if (fscanf(f, "%d", &G_PLANT_CIPHER[i]) != 1) die("dat");
        }
        else if (!strcmp(key, "PLANT_PLAIN")) {
            int n, v; if (fscanf(f, "%d", &n) != 1 || n != LSCREEN) die("PLANT_PLAIN len");
            for (int i = 0; i < n; i++) { if (fscanf(f, "%d", &v) != 1) die("dat"); G_PLANT_PLAIN[i] = (uint8_t)v; }
        }
        else if (!strcmp(key, "NVEC")) { if (fscanf(f, "%d", &nvec_expected) != 1) die("dat"); }
        else if (!strcmp(key, "VEC")) {
            Vec *v = &G_VEC[G_NVEC];
            unsigned long long s;
            if (fscanf(f, "%llu %lf %lf %d %d %d", &s, &v->pmax, &v->beam_score,
                       &v->ptr_end, &v->n_skips, &v->nchars) != 6) die("VEC");
            v->seed = (uint32_t)s;
            char k2[16]; int x;
            if (fscanf(f, "%15s", k2) != 1 || strcmp(k2, "KS")) die("VEC KS");
            for (int i = 0; i < 128; i++) { if (fscanf(f, "%d", &x) != 1) die("KS"); v->ks128[i] = (uint8_t)x; }
            if (fscanf(f, "%15s", k2) != 1 || strcmp(k2, "PLAIN")) die("VEC PLAIN");
            for (int i = 0; i < LSCREEN; i++) { if (fscanf(f, "%d", &x) != 1) die("PLAIN"); v->plain[i] = (uint8_t)x; }
            G_NVEC++;
        }
        else if (!strcmp(key, "END")) break;
        else die("unknown key in engine.dat");
    }
    fclose(f);
    if (nvec_expected != G_NVEC) die("NVEC mismatch");
}

/* ------------------------------------------------------------------ lane config */
typedef struct {
    char name[32];
    int  pair;         /* 1 = keyskip2 'pair', 0 = keyskip1 'exact' */
    int  max_skip;     /* 8 pair / 3 exact */
    int  reducer;
    int  offset;       /* key offset o */
    uint64_t from, to;
    double cand_bar, claim_bar;
    int  nK;           /* padded keystream length */
    char gate[1024];   /* per-cell gate file (grind28: REQUIRED for --plan lanes) */
} Lane;

static void lane_finish_init(Lane *ln) {
    ln->max_skip = ln->pair ? 8 : 3;
    ln->nK = KS_LEN + LSCREEN * (ln->max_skip + 1) + 8;   /* driftbeam zero-pad, section 3.1 */
    if (ln->cand_bar <= 0) ln->cand_bar = G_CAND_BAR;
    if (ln->claim_bar <= 0) ln->claim_bar = ln->pair ? G_CLAIM_PAIR : G_CLAIM_EXACT;
}

static Lane lane_S1(void) {
    Lane ln; memset(&ln, 0, sizeof ln);
    strcpy(ln.name, "S1");
    ln.pair = 1; ln.reducer = RED_RANDOM29; ln.offset = 0;
    ln.from = 0; ln.to = 4294967296ULL;
    lane_finish_init(&ln);
    return ln;
}

/* per-step tables -- depend only on (cipher, relation), NOT the seed */
typedef struct { uint8_t pm[NRUNE], vm[NRUNE]; } StepTab;

static void build_steps(const int *C, StepTab *st) {   /* sign = -1 throughout */
    for (int i = 1; i < LSCREEN; i++) {
        int ci = C[i];
        int delta = MOD29(ci - C[i-1]);                /* (sign*(C[i-1]-ci)) % 29 with sign=-1 */
        for (int k = 0; k < NRUNE; k++) {
            st[i].pm[k] = MOD29(ci - k);               /* (ci + sign*k) % 29 */
            st[i].vm[k] = MOD29(k - delta);
        }
    }
}

/* ------------------------------------------------------------------ beam decode */
typedef struct {
    double sc;                    /* cum score == quad cum (lam = 0) */
    int32_t acc, nid, nchars;
    uint8_t tail[3], tlen, _pad[3];
} Hyp;

typedef struct {                  /* per-thread scratch */
    MT mt;
    PhpMT php;
    GlibcR gl;
    uint8_t Kx[KS_LEN + LSCREEN * 9 + 8 + 8];
    Hyp beams[BEAMW], ch[MAXCH], tmp[MAXCH];
    int16_t par[LSCREEN][MAXCH];
    uint8_t rune[LSCREEN][MAXCH];
    int cnt[NRUNE];
    uint8_t plain[LSCREEN];
} Ctx;

/* stable sort, DESCENDING by sc (Python list.sort(reverse=True) parity).
 * Children arrays are small in practice (avg ~12, max ~128 measured), so a stable
 * insertion sort is the fast path; bottom-up merge covers large n. Both are stable:
 * insertion shifts only on strict <, merge prefers the left run on ties. */
static void stable_sort_desc(Hyp *a, Hyp *t, int n) {
    if (n < 2) return;
    if (n <= 48) {
        for (int i = 1; i < n; i++) {
            if (a[i].sc <= a[i-1].sc) continue;
            Hyp key = a[i];
            int j = i;
            while (j > 0 && a[j-1].sc < key.sc) { a[j] = a[j-1]; j--; }
            a[j] = key;
        }
        return;
    }
    for (int width = 1; width < n; width *= 2) {
        for (int lo = 0; lo < n; lo += 2 * width) {
            int mid = lo + width; if (mid >= n) break;
            int hi2 = lo + 2 * width; if (hi2 > n) hi2 = n;
            int i = lo, j = mid, k = lo;
            while (i < mid && j < hi2)
                t[k++] = (a[i].sc >= a[j].sc) ? a[i++] : a[j++];
            while (i < mid) t[k++] = a[i++];
            while (j < hi2) t[k++] = a[j++];
            memcpy(a + lo, t + lo, sizeof(Hyp) * (size_t)(hi2 - lo));
        }
    }
}

/* Decode `cipher` (120 runes) against ctx->Kx under lane relation; returns final
 * beam-path count artifacts. Mirrors driftbeam.beam_decode exactly (lam=0,
 * max_free=0, start_slack=0, sign=-1). */
typedef struct { double pmax, beam_score; int ptr_end, n_skips, nchars; } DecOut;

static DecOut decode_seed(const Lane *ln, const StepTab *st, const int *cipher, Ctx *cx) {
    const uint8_t *Kx = cx->Kx;
    const int nK = ln->nK, pair = ln->pair, ms = ln->max_skip;
    const int step_pair = pair ? 2 : 1;
    int nb;

    /* init hypothesis (start_slack = 0) */
    {
        int acc0 = ln->offset;
        int p0 = MOD29(cipher[0] - Kx[acc0]);
        Hyp *h = &cx->beams[0];
        h->sc = 0.0; h->acc = acc0; h->nid = 0;
        h->tlen = TL[p0]; h->tail[0] = TC0[p0]; h->tail[1] = TC1[p0];
        h->nchars = TL[p0];
        cx->par[0][0] = -1; cx->rune[0][0] = (uint8_t)p0;
        nb = 1;
    }
    memset(cx->cnt, 0, sizeof cx->cnt);

    for (int i = 1; i < LSCREEN; i++) {
        const uint8_t *pm = st[i].pm, *vm = st[i].vm;
        int nch = 0;
        int16_t *par_row = cx->par[i];
        uint8_t *rune_row = cx->rune[i];
        for (int b = 0; b < nb; b++) {
            const Hyp *h = &cx->beams[b];
            const int base = h->acc + 1;
            int hi = base, maxcnt = 0;
            const int L1 = h->nchars;
            const int long_form = (L1 < 3);
            for (int dsk = 0; dsk <= ms; dsk++) {
                const int acc = base + dsk;
                if (acc >= nK) break;
                int need;
                if (dsk) {
                    if (!pair || (dsk & 1)) {
                        int km = Kx[acc - 1];
                        int c2 = ++cx->cnt[km];
                        if (c2 > maxcnt) maxcnt = c2;
                    }
                    hi = acc;
                    if (pair) {
                        if (dsk & 1) continue;         /* only even advances representable */
                        need = dsk >> 1;
                    } else need = dsk;
                    if (need - maxcnt > 0) break;      /* max_free = 0, monotone prune */
                } else need = 0;
                const int kacc = Kx[acc];
                if (need - cx->cnt[vm[kacc]] > 0) continue;   /* consistency reject */
                const int p = pm[kacc];
                const int la = TL[p];
                double tot;
                uint8_t nt0, nt1, nt2, ntl;
                if (!long_form) {                      /* tlen == 3 guaranteed */
                    const int b3 = (h->tail[0] * 26 + h->tail[1]) * 26 + h->tail[2];
                    if (la == 1) {
                        const int a4 = b3 * 26 + TC0[p];
                        tot = QTAB[a4];
                        nt0 = h->tail[1]; nt1 = h->tail[2]; nt2 = TC0[p]; ntl = 3;
                    } else {
                        const int a4 = b3 * 26 + TC0[p];
                        tot = QTAB[a4] + QTAB[(a4 % 17576) * 26 + TC1[p]];
                        nt0 = h->tail[2]; nt1 = TC0[p]; nt2 = TC1[p]; ntl = 3;
                    }
                } else {                               /* whole translit < 3 chars */
                    uint8_t s2[5]; int n2 = 0;
                    for (int m = 0; m < h->tlen; m++) s2[n2++] = h->tail[m];
                    s2[n2++] = TC0[p];
                    if (la == 2) s2[n2++] = TC1[p];
                    tot = (n2 >= 4)
                        ? QTAB[((s2[0] * 26 + s2[1]) * 26 + s2[2]) * 26 + s2[3]]
                        : 0.0;
                    ntl = (uint8_t)(n2 < 3 ? n2 : 3);
                    nt0 = s2[n2 - ntl]; nt1 = ntl > 1 ? s2[n2 - ntl + 1] : 0;
                    nt2 = ntl > 2 ? s2[n2 - ntl + 2] : 0;
                }
                Hyp *c = &cx->ch[nch];
                c->sc = h->sc + tot;
                c->acc = acc; c->nchars = L1 + la;
                c->tail[0] = nt0; c->tail[1] = nt1; c->tail[2] = nt2; c->tlen = ntl;
                c->nid = nch;
                par_row[nch] = (int16_t)h->nid;
                rune_row[nch] = (uint8_t)p;
                nch++;
            }
            if (hi > base)                             /* histogram reset (touched entries only) */
                for (int m = base; m < hi; m += step_pair) cx->cnt[Kx[m]] = 0;
        }
        stable_sort_desc(cx->ch, cx->tmp, nch);
        nb = nch < BEAMW ? nch : BEAMW;
        memcpy(cx->beams, cx->ch, sizeof(Hyp) * (size_t)nb);
    }

    /* best path + backtrack (beams[0] is max after the stable descending sort) */
    const Hyp *best = &cx->beams[0];
    int node = best->nid;
    for (int step = LSCREEN - 1; step >= 0; step--) {
        cx->plain[step] = cx->rune[step][node];
        node = cx->par[step][node];
    }

    /* panel-max: 118 trigrams, float32 gathers accumulated in double */
    double acc9[NREG] = {0};
    for (int i = 0; i < LSCREEN - 2; i++) {
        const int fidx = (cx->plain[i] * NRUNE + cx->plain[i+1]) * NRUNE + cx->plain[i+2];
        const float *row = LMT + fidx * NREG;
        for (int r = 0; r < NREG; r++) acc9[r] += row[r];
    }
    double pmax = -1e30;
    for (int r = 0; r < NREG; r++) {
        const double z = (acc9[r] / 118.0 - MU[r]) / SD[r];
        if (z > pmax) pmax = z;
    }

    DecOut o;
    o.pmax = pmax;
    o.beam_score = best->nchars > 3 ? best->sc / (double)(best->nchars - 3) : -999.0;
    o.ptr_end = best->acc;
    o.n_skips = best->acc - ln->offset - (LSCREEN - 1);
    o.nchars = best->nchars;
    return o;
}

/* generate KS_LEN post-reducer runes for seed w under any registered generator */
static void gen_ks(Ctx *cx, int reducer, uint32_t w, uint8_t *ks, int n) {
    switch (reducer) {
    case RED_RANDOM29: case RED_GRB5_MOD: case RED_GRB5_REJ: case RED_SHUFFLE29:
        mt_init_word(&cx->mt, w);                 /* CPython 2.7 init_by_array([w]) */
        reduce_stream(&cx->mt, reducer, ks, n);
        break;
    case RED_PHP_MT_SCALE:
        php_init(&cx->php, w, 0);
        for (int i = 0; i < n; i++) ks[i] = php_badscale(php_rand31(&cx->php));
        break;
    case RED_PHP_MT_MOD:
        php_init(&cx->php, w, 0);
        for (int i = 0; i < n; i++) ks[i] = (uint8_t)(php_rand31(&cx->php) % 29u);
        break;
    case RED_PHP_PHP_SCALE:
        php_init(&cx->php, w, 1);
        for (int i = 0; i < n; i++) ks[i] = php_badscale(php_rand31(&cx->php));
        break;
    case RED_PHP_PHP_MOD:
        php_init(&cx->php, w, 1);
        for (int i = 0; i < n; i++) ks[i] = (uint8_t)(php_rand31(&cx->php) % 29u);
        break;
    case RED_GLIBC_MOD:
        glibc_init(&cx->gl, w);
        for (int i = 0; i < n; i++) ks[i] = (uint8_t)(glibc_next31(&cx->gl) % 29u);
        break;
    default:
        die("gen_ks: unknown reducer");
    }
}

static DecOut screen_one(const Lane *ln, const StepTab *st, const int *cipher,
                         Ctx *cx, uint32_t w) {
    gen_ks(cx, ln->reducer, w, cx->Kx, KS_LEN);
    memset(cx->Kx + KS_LEN, 0, (size_t)(ln->nK - KS_LEN));
    return decode_seed(ln, st, cipher, cx);
}

/* ------------------------------------------------------------------ self-test (V1 + V2)
 * plant_out (optional): receives the V2 planted-screen DecOut so --mode self-test can
 * emit the contract JSON line without re-running the decode. */
static int self_test(DecOut *plant_out) {
    Lane ln = lane_S1();
    StepTab *st = calloc(LSCREEN, sizeof(StepTab));
    build_steps(C_SCREEN, st);
    Ctx *cx = calloc(1, sizeof(Ctx));
    int fails = 0;
    double worst_pmax = 0, worst_beam = 0;

    for (int v = 0; v < G_NVEC; v++) {
        Vec *V = &G_VEC[v];
        mt_init_word(&cx->mt, V->seed);
        uint8_t ks[128];
        reduce_stream(&cx->mt, RED_RANDOM29, ks, 128);
        if (memcmp(ks, V->ks128, 128)) {
            printf("V1 FAIL seed %u: ks128 mismatch\n", V->seed); fails++; continue;
        }
        DecOut o = screen_one(&ln, st, C_SCREEN, cx, V->seed);
        int pm_ok = memcmp(cx->plain, V->plain, LSCREEN) == 0;
        double dp = fabs(o.pmax - V->pmax), db = fabs(o.beam_score - V->beam_score);
        if (dp > worst_pmax) worst_pmax = dp;
        if (db > worst_beam) worst_beam = db;
        if (!pm_ok || dp > 1e-9 || db > 1e-9 || o.ptr_end != V->ptr_end
            || o.n_skips != V->n_skips || o.nchars != V->nchars) {
            printf("V1 FAIL seed %u: plain_ok=%d dpmax=%.3e dbeam=%.3e ptr %d/%d "
                   "skips %d/%d nchars %d/%d\n", V->seed, pm_ok, dp, db,
                   o.ptr_end, V->ptr_end, o.n_skips, V->n_skips, o.nchars, V->nchars);
            fails++;
        }
    }
    printf("V1 vector parity: %d/%d seeds exact (worst |dpmax| %.3e, worst |dbeam| %.3e) -> %s\n",
           G_NVEC - fails, G_NVEC, worst_pmax, worst_beam, fails ? "FAIL" : "PASS");

    /* V2: planted stage-A screen -- decode the plant cipher with seed 777
       (step tables are cipher-dependent: build them for the plant cipher) */
    StepTab *stp = calloc(LSCREEN, sizeof(StepTab));
    build_steps(G_PLANT_CIPHER, stp);
    DecOut o = screen_one(&ln, stp, G_PLANT_CIPHER, cx, (uint32_t)G_PLANT_SEED);
    free(stp);
    if (plant_out) *plant_out = o;
    int plain_ok = memcmp(cx->plain, G_PLANT_PLAIN, LSCREEN) == 0;
    double dp = fabs(o.pmax - G_PLANT_PMAX);
    int v2ok = plain_ok && dp <= 1e-9 && o.pmax >= ln.cand_bar;
    printf("V2 planted screen: seed %d pmax %.15g (ref %.15g, |d| %.3e) plain_ok=%d "
           ">= cand_bar %.1f: %s -> %s\n", G_PLANT_SEED, o.pmax, G_PLANT_PMAX, dp,
           plain_ok, ln.cand_bar, o.pmax >= ln.cand_bar ? "yes (candidate emitted)" : "NO",
           v2ok ? "PASS" : "FAIL");
    if (!v2ok) fails++;

    free(cx); free(st);
    if (fails) { printf("SELF-TEST: FAIL (%d)\n", fails); return 1; }
    printf("SELF-TEST: PASS -- screen is provably incapable of rejecting the planted "
           "true seed (margin %.2f over bar %.1f). Python (hitfn20) remains the "
           "adjudicator of record on every candidate.\n",
           o.pmax - ln.cand_bar, ln.cand_bar);
    return 0;
}

/* ------------------------------------------------------------------ per-cell gates
 * (grind28: PREREG Q1 gates (a)(b)(c), rebuilt from make_gates.py output and
 * re-verified through the REAL screen code path at every launch). */
typedef struct {
    char lane[32], reducer[32], relation[16];
    int  offset;
    double cand_bar, claim_bar;
    int  nvec;
    Vec  vec[128];
    int  plant_seed;
    double plant_pmax;
    int  plant_cipher[LSCREEN];
    uint8_t plant_plain[LSCREEN];
    int  nfr;
    struct { uint32_t seed; double pmax; } fr[16];
} Gate;

static void gate_load(const char *path, Gate *g) {
    memset(g, 0, sizeof *g);
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "FATAL: cannot open gate file %s\n", path); exit(1); }
    char key[64];
    int ver;
    if (fscanf(f, "%63s %d", key, &ver) != 2 || strcmp(key, "GRIND28GATE") || ver != 1)
        die("bad gate header");
    while (fscanf(f, "%63s", key) == 1) {
        if (!strcmp(key, "LANE")) { if (fscanf(f, "%31s", g->lane) != 1) die("gate"); }
        else if (!strcmp(key, "REDUCER")) { if (fscanf(f, "%31s", g->reducer) != 1) die("gate"); }
        else if (!strcmp(key, "RELATION")) { if (fscanf(f, "%15s", g->relation) != 1) die("gate"); }
        else if (!strcmp(key, "OFFSET")) { if (fscanf(f, "%d", &g->offset) != 1) die("gate"); }
        else if (!strcmp(key, "CAND_BAR")) { if (fscanf(f, "%lf", &g->cand_bar) != 1) die("gate"); }
        else if (!strcmp(key, "CLAIM_BAR")) { if (fscanf(f, "%lf", &g->claim_bar) != 1) die("gate"); }
        else if (!strcmp(key, "NVEC")) { int x; if (fscanf(f, "%d", &x) != 1 || x > 128) die("gate NVEC"); }
        else if (!strcmp(key, "VEC")) {
            Vec *v = &g->vec[g->nvec];
            unsigned long long s;
            if (fscanf(f, "%llu %lf %lf %d %d %d", &s, &v->pmax, &v->beam_score,
                       &v->ptr_end, &v->n_skips, &v->nchars) != 6) die("gate VEC");
            v->seed = (uint32_t)s;
            char k2[16]; int x;
            if (fscanf(f, "%15s", k2) != 1 || strcmp(k2, "KS")) die("gate KS");
            for (int i = 0; i < 128; i++) { if (fscanf(f, "%d", &x) != 1) die("KS"); v->ks128[i] = (uint8_t)x; }
            if (fscanf(f, "%15s", k2) != 1 || strcmp(k2, "PLAIN")) die("gate PLAIN");
            for (int i = 0; i < LSCREEN; i++) { if (fscanf(f, "%d", &x) != 1) die("PLAIN"); v->plain[i] = (uint8_t)x; }
            g->nvec++;
        }
        else if (!strcmp(key, "PLANT_SEED")) { if (fscanf(f, "%d", &g->plant_seed) != 1) die("gate"); }
        else if (!strcmp(key, "PLANT_PMAX")) { if (fscanf(f, "%lf", &g->plant_pmax) != 1) die("gate"); }
        else if (!strcmp(key, "PLANT_CIPHER")) {
            int n; if (fscanf(f, "%d", &n) != 1 || n != LSCREEN) die("gate PLANT_CIPHER");
            for (int i = 0; i < n; i++) if (fscanf(f, "%d", &g->plant_cipher[i]) != 1) die("gate");
        }
        else if (!strcmp(key, "PLANT_PLAIN")) {
            int n, v; if (fscanf(f, "%d", &n) != 1 || n != LSCREEN) die("gate PLANT_PLAIN");
            for (int i = 0; i < n; i++) { if (fscanf(f, "%d", &v) != 1) die("gate"); g->plant_plain[i] = (uint8_t)v; }
        }
        else if (!strcmp(key, "NFR")) { if (fscanf(f, "%d", &g->nfr) != 1 || g->nfr > 16) die("gate NFR"); }
        else if (!strcmp(key, "FR")) {
            /* FR lines follow NFR in the file; slot = first unused (seeds are
             * never 0 in the FR set, and the struct is zero-initialised) */
            unsigned long long s; double pm;
            if (fscanf(f, "%llu %lf", &s, &pm) != 2) die("gate FR");
            int fi = 0;
            while (fi < 16 && g->fr[fi].seed) fi++;
            if (fi >= 16 || fi >= g->nfr) die("gate FR overflow/order");
            g->fr[fi].seed = (uint32_t)s; g->fr[fi].pmax = pm;
        }
        else if (!strcmp(key, "END")) break;
        else die("unknown key in gate file");
    }
    fclose(f);
}

/* Run gates (a)+(b)+(c) for one cell through the REAL screen path. rc 0 = PASS. */
static int gate_check(const Gate *g, int verbose) {
    Lane ln; memset(&ln, 0, sizeof ln);
    snprintf(ln.name, sizeof ln.name, "%s", g->lane);
    ln.pair = !strcmp(g->relation, "pair");
    if (!ln.pair && strcmp(g->relation, "exact")) die("gate relation");
    ln.reducer = reducer_from_name(g->reducer);
    if (ln.reducer < 0) die("gate reducer unknown");
    ln.offset = g->offset;
    ln.cand_bar = g->cand_bar; ln.claim_bar = g->claim_bar;
    lane_finish_init(&ln);

    Ctx *cx = calloc(1, sizeof(Ctx));
    StepTab *st = calloc(LSCREEN, sizeof(StepTab));
    build_steps(C_SCREEN, st);
    int fails = 0;
    double worst = 0;

    /* (a) 64-vector parity: generator |delta|=0 + decode artifact parity */
    for (int i = 0; i < g->nvec; i++) {
        const Vec *V = &g->vec[i];
        uint8_t ks[128];
        gen_ks(cx, ln.reducer, V->seed, ks, 128);
        if (memcmp(ks, V->ks128, 128)) {
            printf("GATE %s: V1 FAIL seed %u ks128 mismatch (generator not exact)\n",
                   g->lane, V->seed);
            fails++; continue;
        }
        DecOut o = screen_one(&ln, st, C_SCREEN, cx, V->seed);
        double dp = fabs(o.pmax - V->pmax);
        if (dp > worst) worst = dp;
        if (memcmp(cx->plain, V->plain, LSCREEN) || dp > 1e-9
            || fabs(o.beam_score - V->beam_score) > 1e-9
            || o.ptr_end != V->ptr_end || o.n_skips != V->n_skips
            || o.nchars != V->nchars) {
            printf("GATE %s: V1 FAIL seed %u dpmax=%.3e ptr %d/%d skips %d/%d\n",
                   g->lane, V->seed, dp, o.ptr_end, V->ptr_end, o.n_skips, V->n_skips);
            fails++;
        }
    }

    /* (b) planted-control screen: MUST be flagged with the reference pmax */
    StepTab *stp = calloc(LSCREEN, sizeof(StepTab));
    build_steps(g->plant_cipher, stp);
    DecOut po = screen_one(&ln, stp, g->plant_cipher, cx, (uint32_t)g->plant_seed);
    double pdp = fabs(po.pmax - g->plant_pmax);
    int plant_ok = memcmp(cx->plain, g->plant_plain, LSCREEN) == 0
                   && pdp <= 1e-9 && po.pmax >= ln.cand_bar;
    if (!plant_ok) {
        printf("GATE %s: V2 FAIL plant seed %d pmax %.15g ref %.15g (|d|=%.3e)\n",
               g->lane, g->plant_seed, po.pmax, g->plant_pmax, pdp);
        fails++;
    }

    /* (c) false-reject: every wrong seed matched and below the cell claim bar */
    for (int i = 0; i < g->nfr; i++) {
        DecOut o = screen_one(&ln, stp, g->plant_cipher, cx, g->fr[i].seed);
        if (fabs(o.pmax - g->fr[i].pmax) > 1e-9 || o.pmax >= g->claim_bar) {
            printf("GATE %s: FR FAIL seed %u pmax %.15g ref %.15g claim %.6g\n",
                   g->lane, g->fr[i].seed, o.pmax, g->fr[i].pmax, g->claim_bar);
            fails++;
        }
    }
    free(stp); free(st); free(cx);
    if (verbose || fails)
        printf("GATE %s [%s/%s/o%d]: vectors %d (worst |dpmax| %.3e, %d fail(s) "
               "total), plant %s (pmax %.6f, margin %.2f over cand / %.2f over "
               "claim), FR %d seeds -> %s\n",
               g->lane, g->reducer, g->relation, g->offset, g->nvec, worst, fails,
               plant_ok ? "FLAGGED" : "MISSED", po.pmax, po.pmax - ln.cand_bar,
               po.pmax - g->claim_bar, g->nfr, fails ? "FAIL" : "PASS");
    return fails ? 1 : 0;
}

/* ------------------------------------------------------------------ drill (V3) + bench */
static int drill(void) {
    Lane ln = lane_S1();
    StepTab *st = calloc(LSCREEN, sizeof(StepTab));
    build_steps(C_SCREEN, st);
    Ctx *cx = calloc(1, sizeof(Ctx));
    const uint64_t a = 2149309680ULL, b = 2149309700ULL;
    double best = -1e30; uint64_t bw = 0;
    for (uint64_t w = a; w < b; w++) {
        DecOut o = screen_one(&ln, st, C_SCREEN, cx, (uint32_t)w);
        if (o.pmax >= ln.cand_bar)
            printf("  candidate: seed %llu pmax %.15g (would append to candidates.jsonl)\n",
                   (unsigned long long)w, o.pmax);
        if (o.pmax > best) { best = o.pmax; bw = w; }
    }
    const double ref = 6.825835461843649;
    int ok = (bw == 2149309687ULL) && fabs(best - ref) <= 1e-9;
    printf("V3 drill [%llu,%llu): best word %llu pmax %.15g (ref 2149309687 @ %.15g) -> %s\n",
           (unsigned long long)a, (unsigned long long)b, (unsigned long long)bw, best, ref,
           ok ? "PASS" : "FAIL");
    free(cx); free(st);
    return ok ? 0 : 1;
}

/* grind28: --reducer/--relation/--offset override for bench + contract modes
 * (calibration and Python batch-parity re-scoring of any cell) */
static int G_OV_REDUCER = -1, G_OV_PAIR = -1, G_OV_OFFSET = -1;

static void lane_apply_override(Lane *ln) {
    if (G_OV_REDUCER >= 0) ln->reducer = G_OV_REDUCER;
    if (G_OV_PAIR >= 0)    ln->pair = G_OV_PAIR;
    if (G_OV_OFFSET >= 0)  ln->offset = G_OV_OFFSET;
    ln->claim_bar = 0;                 /* re-derive for the overridden relation */
    lane_finish_init(ln);
}

static int bench(uint64_t n, int nthreads) {
    Lane ln = lane_S1();
    lane_apply_override(&ln);
    StepTab *st = calloc(LSCREEN, sizeof(StepTab));
    build_steps(C_SCREEN, st);
    const uint64_t start = 3000000ULL;
    double t0 = omp_get_wtime();
    double best = -1e30; uint64_t bw = 0; uint64_t ncand = 0;
    #pragma omp parallel num_threads(nthreads)
    {
        Ctx *cx = calloc(1, sizeof(Ctx));
        double lbest = -1e30; uint64_t lbw = 0, lc = 0;
        #pragma omp for schedule(static)
        for (uint64_t w = start; w < start + n; w++) {
            DecOut o = screen_one(&ln, st, C_SCREEN, cx, (uint32_t)w);
            if (o.pmax > lbest) { lbest = o.pmax; lbw = w; }
            if (o.pmax >= ln.cand_bar) lc++;
        }
        #pragma omp critical
        { if (lbest > best) { best = lbest; bw = lbw; } ncand += lc; }
        free(cx);
    }
    double dt = omp_get_wtime() - t0;
    printf("bench: %llu seeds, %d threads, %.2f s -> %.0f seeds/s aggregate "
           "(%.0f /s/thread); best pmax %.6f @ %llu; candidates>=%.1f: %llu\n",
           (unsigned long long)n, nthreads, dt, n / dt, n / dt / nthreads,
           best, (unsigned long long)bw, ln.cand_bar, (unsigned long long)ncand);
    free(st);
    return 0;
}

/* ------------------------------------------------------------------ tiny JSON helpers (files we author) */
static char *slurp(const char *path, long *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    char *b = malloc((size_t)n + 1);
    if (fread(b, 1, (size_t)n, f) != (size_t)n) { fclose(f); free(b); return NULL; }
    b[n] = 0; fclose(f);
    if (len) *len = n;
    return b;
}

/* find `"key"` inside [s,e), return pointer just past the ':' (NULL if absent) */
static const char *jkey(const char *s, const char *e, const char *key) {
    char pat[80]; snprintf(pat, sizeof pat, "\"%s\"", key);
    size_t pl = strlen(pat);
    for (const char *p = s; p + pl < e; p++) {
        if (!memcmp(p, pat, pl)) {
            const char *q = p + pl;
            while (q < e && (*q == ' ' || *q == '\t' || *q == '\n' || *q == '\r')) q++;
            if (q < e && *q == ':') return q + 1;
        }
    }
    return NULL;
}

static double jnum(const char *s, const char *e, const char *key, double dflt) {
    const char *p = jkey(s, e, key);
    return p ? strtod(p, NULL) : dflt;
}

static int jstr(const char *s, const char *e, const char *key, char *out, int cap) {
    const char *p = jkey(s, e, key);
    if (!p) return 0;
    while (p < e && *p != '"') p++;
    if (p >= e) return 0;
    p++;
    int i = 0;
    while (p < e && *p != '"' && i < cap - 1) out[i++] = *p++;
    out[i] = 0;
    return 1;
}

/* iterate top-level {...} objects inside the [] that starts at *pp; returns spans */
static int jnext_obj(const char **pp, const char *e, const char **os, const char **oe) {
    const char *p = *pp;
    while (p < e && *p != '{') { if (*p == ']') return 0; p++; }
    if (p >= e) return 0;
    int depth = 0; const char *q = p;
    while (q < e) {
        if (*q == '{') depth++;
        else if (*q == '}') { depth--; if (!depth) break; }
        q++;
    }
    if (q >= e) return 0;
    *os = p; *oe = q + 1; *pp = q + 1;
    return 1;
}

/* ------------------------------------------------------------------ sweep-plan runner */
static volatile sig_atomic_t G_STOP = 0;
static void on_sig(int s) { (void)s; G_STOP = 1; }

typedef struct {
    uint64_t band_start, band_end;
    volatile uint64_t cursor;
    volatile uint64_t seeds_done;
    volatile uint64_t n_cand;
    double best_pmax;              /* owner-thread written */
    uint64_t best_word;
    int done;
} Worker;

typedef struct { uint64_t seed; double pmax; } Top;

static char G_RUNDIR[1024] = ".";
static char G_PLANPATH[1024] = "";
static Worker G_W[MAX_WORKERS];
static int G_NW = 6;
static uint64_t *G_HIST;           /* nw * HIST_BINS */
static Top G_TOP[TOPK]; static int G_NTOP = 0;   /* min-heap on pmax */
static FILE *G_CANDF = NULL;
static Top G_HITS[MAX_HITS]; static int G_NHITS = 0;
static char G_DONE_LANES[MAX_LANES][32]; static int G_NDONE = 0;
static double G_RUN_T0; static uint64_t G_RUN_DONE0;

static void heap_push(uint64_t seed, double pm) {
    if (G_NTOP < TOPK) {
        int i = G_NTOP++;
        G_TOP[i].seed = seed; G_TOP[i].pmax = pm;
        while (i && G_TOP[(i-1)/2].pmax > G_TOP[i].pmax) {
            Top t = G_TOP[i]; G_TOP[i] = G_TOP[(i-1)/2]; G_TOP[(i-1)/2] = t; i = (i-1)/2;
        }
        return;
    }
    if (pm <= G_TOP[0].pmax) return;
    G_TOP[0].seed = seed; G_TOP[0].pmax = pm;
    int i = 0;
    for (;;) {
        int l = 2*i+1, r = 2*i+2, m = i;
        if (l < TOPK && G_TOP[l].pmax < G_TOP[m].pmax) m = l;
        if (r < TOPK && G_TOP[r].pmax < G_TOP[m].pmax) m = r;
        if (m == i) break;
        Top t = G_TOP[i]; G_TOP[i] = G_TOP[m]; G_TOP[m] = t; i = m;
    }
}

static int top_cmp_desc(const void *a, const void *b) {
    const Top *x = a, *y = b;
    if (x->pmax != y->pmax) return x->pmax > y->pmax ? -1 : 1;
    return x->seed < y->seed ? -1 : x->seed > y->seed ? 1 : 0;
}

static void write_hits_file(const Lane *ln) {
    char p[1200]; snprintf(p, sizeof p, "%s/HIT-CANDIDATE.json", G_RUNDIR);
    char tp[1220]; snprintf(tp, sizeof tp, "%s.tmp", p);
    FILE *f = fopen(tp, "w");
    if (!f) return;
    fprintf(f, "{\n \"note\": \"pmax >= lane claim bar at the C SCREEN. FLAGGED-FOR-ORACLE"
               " pending Python stage_b (hitfn20 3-clause) adjudication -- NEVER"
               " auto-certified (R21-L1). The sweep continued.\",\n \"lane\": \"%s\","
               " \"claim_bar\": %.17g,\n \"hits\": [\n", ln->name, ln->claim_bar);
    for (int i = 0; i < G_NHITS; i++)
        fprintf(f, "  {\"seed\": %llu, \"pmax\": %.17g}%s\n",
                (unsigned long long)G_HITS[i].seed, G_HITS[i].pmax,
                i + 1 < G_NHITS ? "," : "");
    fprintf(f, " ]\n}\n");
    fclose(f);
    rename(tp, p);
}

static void write_status(const Lane *ln, int final) {
    char p[1200]; snprintf(p, sizeof p, "%s/STATUS.json", G_RUNDIR);
    char tp[1220]; snprintf(tp, sizeof tp, "%s.tmp", p);
    FILE *f = fopen(tp, "w");
    if (!f) return;
    uint64_t done = 0, cov = 0, cand = 0;
    double best = -1e30; uint64_t bw = 0;
    for (int i = 0; i < G_NW; i++) {
        done += G_W[i].seeds_done;
        cov  += G_W[i].cursor - G_W[i].band_start;
        cand += G_W[i].n_cand;
        if (G_W[i].best_pmax > best) { best = G_W[i].best_pmax; bw = G_W[i].best_word; }
    }
    double dt = omp_get_wtime() - G_RUN_T0;
    double thr = dt > 0 ? (double)(done - G_RUN_DONE0) / dt : 0.0;
    fprintf(f, "{\n \"engine\": \"grind28\", \"plan_path\": \"%s\",\n"
               " \"current_lane\": \"%s\", \"relation\": \"%s\", \"reducer_id\": %d,"
               " \"offset\": %d,\n \"from\": %llu, \"to\": %llu,\n"
               " \"cand_bar\": %.17g, \"claim_bar\": %.17g,\n",
            G_PLANPATH, ln->name, ln->pair ? "pair" : "exact", ln->reducer, ln->offset,
            (unsigned long long)ln->from, (unsigned long long)ln->to,
            ln->cand_bar, ln->claim_bar);
    fprintf(f, " \"lanes_completed\": [");
    for (int i = 0; i < G_NDONE; i++)
        fprintf(f, "%s\"%s\"", i ? ", " : "", G_DONE_LANES[i]);
    fprintf(f, "],\n \"workers\": [\n");
    for (int i = 0; i < G_NW; i++) {
        Worker *w = &G_W[i];
        fprintf(f, "  {\"worker\": %d, \"band_start\": %llu, \"band_end\": %llu,"
                   " \"cursor\": %llu, \"seeds_done\": %llu,"
                   " \"seeds_skipped_excluded\": 0, \"best_pmax\": %.17g,"
                   " \"best_word\": %llu, \"n_candidates\": %llu,"
                   " \"flagged_survivors\": [], \"done\": %s}%s\n",
                i, (unsigned long long)w->band_start, (unsigned long long)w->band_end,
                (unsigned long long)w->cursor, (unsigned long long)w->seeds_done,
                w->best_pmax, (unsigned long long)w->best_word,
                (unsigned long long)w->n_cand,
                w->done ? "true" : "false", i + 1 < G_NW ? "," : "");
    }
    fprintf(f, " ],\n \"aggregate\": {\"seeds_done\": %llu,"
               " \"lane_words_covered\": %llu, \"lane_coverage_fraction\": %.9f,"
               " \"best_pmax\": %.17g, \"best_word\": %llu, \"n_candidates\": %llu,"
               " \"n_claim_bar_hits\": %d, \"throughput_seeds_per_s\": %.1f},\n",
            (unsigned long long)done, (unsigned long long)cov,
            (double)cov / (double)(ln->to - ln->from), best, (unsigned long long)bw,
            (unsigned long long)cand, G_NHITS, thr);
    fprintf(f, " \"final_flush\": %s, \"updated_unix\": %ld\n}\n",
            final ? "true" : "false", (long)time(NULL));
    fclose(f);
    rename(tp, p);
}

static void flush_all(const Lane *ln, int final) {
    write_status(ln, final);
    /* per-worker pmax histogram (uint64 LE, nw x 2600 bins of 0.01 over [0,26)) */
    char p[1200]; snprintf(p, sizeof p, "%s/hist_%s.u64", G_RUNDIR, ln->name);
    char tp[1220]; snprintf(tp, sizeof tp, "%s.tmp", p);
    FILE *f = fopen(tp, "wb");
    if (f) {
        fwrite(G_HIST, sizeof(uint64_t), (size_t)G_NW * HIST_BINS, f);
        fclose(f); rename(tp, p);
    }
    /* global top-1024 */
    snprintf(p, sizeof p, "%s/top_%s.json", G_RUNDIR, ln->name);
    snprintf(tp, sizeof tp, "%s.tmp", p);
    f = fopen(tp, "w");
    if (f) {
        Top sorted[TOPK];
        memcpy(sorted, G_TOP, sizeof(Top) * (size_t)G_NTOP);
        qsort(sorted, (size_t)G_NTOP, sizeof(Top), top_cmp_desc);
        fprintf(f, "[\n");
        for (int i = 0; i < G_NTOP; i++)
            fprintf(f, " {\"seed\": %llu, \"pmax\": %.17g}%s\n",
                    (unsigned long long)sorted[i].seed, sorted[i].pmax,
                    i + 1 < G_NTOP ? "," : "");
        fprintf(f, "]\n");
        fclose(f); rename(tp, p);
    }
    if (G_CANDF) { fflush(G_CANDF); fsync(fileno(G_CANDF)); }
}

static void load_lane_state(const Lane *ln) {
    /* resume: STATUS.json (cursors) + hist + top for THIS lane, if present */
    char p[2048]; long n;
    snprintf(p, sizeof p, "%s/STATUS.json", G_RUNDIR);
    char *s = slurp(p, &n);
    if (s) {
        char cur[64] = "";
        jstr(s, s + n, "current_lane", cur, sizeof cur);
        if (!strcmp(cur, ln->name)) {
            const char *wa = jkey(s, s + n, "workers");
            if (wa) {
                const char *pp = wa, *os, *oe; int i = 0;
                while (i < G_NW && jnext_obj(&pp, s + n, &os, &oe)) {
                    G_W[i].band_start = (uint64_t)jnum(os, oe, "band_start", (double)G_W[i].band_start);
                    G_W[i].band_end   = (uint64_t)jnum(os, oe, "band_end", (double)G_W[i].band_end);
                    G_W[i].cursor     = (uint64_t)jnum(os, oe, "cursor", (double)G_W[i].band_start);
                    G_W[i].seeds_done = (uint64_t)jnum(os, oe, "seeds_done", 0);
                    G_W[i].n_cand     = (uint64_t)jnum(os, oe, "n_candidates", 0);
                    G_W[i].best_pmax  = jnum(os, oe, "best_pmax", -1e30);
                    G_W[i].best_word  = (uint64_t)jnum(os, oe, "best_word", 0);
                    G_W[i].done       = G_W[i].cursor >= G_W[i].band_end;
                    i++;
                }
                if (i == G_NW)
                    printf("resumed lane %s from STATUS.json\n", ln->name);
            }
        }
        free(s);
    }
    snprintf(p, sizeof p, "%s/hist_%s.u64", G_RUNDIR, ln->name);
    FILE *f = fopen(p, "rb");
    if (f) {
        if (fread(G_HIST, sizeof(uint64_t), (size_t)G_NW * HIST_BINS, f)
            != (size_t)G_NW * HIST_BINS)
            memset(G_HIST, 0, sizeof(uint64_t) * (size_t)G_NW * HIST_BINS);
        fclose(f);
    }
    snprintf(p, sizeof p, "%s/top_%s.json", G_RUNDIR, ln->name);
    s = slurp(p, &n);
    if (s) {
        const char *pp = s, *os, *oe;
        while (jnext_obj(&pp, s + n, &os, &oe)) {
            uint64_t seed = (uint64_t)jnum(os, oe, "seed", 0);
            double pm = jnum(os, oe, "pmax", -1e30);
            if (pm > -1e29) heap_push(seed, pm);
        }
        free(s);
    }
}

/* returns 0 = lane completed, 1 = interrupted (time/signal) */
static int run_lane(const Lane *ln, double seconds) {
    StepTab *st = calloc(LSCREEN, sizeof(StepTab));
    build_steps(C_SCREEN, st);

    /* fresh band partition (overridden by resume if STATUS matches this lane) */
    uint64_t total = ln->to - ln->from, step = total / (uint64_t)G_NW;
    for (int i = 0; i < G_NW; i++) {
        G_W[i].band_start = ln->from + (uint64_t)i * step;
        G_W[i].band_end = (i == G_NW - 1) ? ln->to : ln->from + (uint64_t)(i + 1) * step;
        G_W[i].cursor = G_W[i].band_start;
        G_W[i].seeds_done = 0; G_W[i].n_cand = 0;
        G_W[i].best_pmax = -1e30; G_W[i].best_word = 0; G_W[i].done = 0;
    }
    memset(G_HIST, 0, sizeof(uint64_t) * (size_t)G_NW * HIST_BINS);
    G_NTOP = 0; G_NHITS = 0;
    load_lane_state(ln);

    uint64_t pre_done = 0;
    for (int i = 0; i < G_NW; i++) pre_done += G_W[i].seeds_done;
    G_RUN_T0 = omp_get_wtime(); G_RUN_DONE0 = pre_done;

    printf("lane %s: relation=%s reducer=%d offset=%d [%llu, %llu) cand_bar=%.3f "
           "claim_bar=%.6f workers=%d\n", ln->name, ln->pair ? "pair" : "exact",
           ln->reducer, ln->offset, (unsigned long long)ln->from,
           (unsigned long long)ln->to, ln->cand_bar, ln->claim_bar, G_NW);
    for (int i = 0; i < G_NW; i++)
        printf("  w%d band [%llu, %llu) cursor=%llu%s\n", i,
               (unsigned long long)G_W[i].band_start, (unsigned long long)G_W[i].band_end,
               (unsigned long long)G_W[i].cursor, G_W[i].done ? " [done]" : "");
    fflush(stdout);

    double t_deadline = seconds > 0 ? omp_get_wtime() + seconds : 0;
    volatile int alldone = 0;

    #pragma omp parallel num_threads(G_NW)
    {
        int wi = omp_get_thread_num();
        Worker *W = &G_W[wi];
        Ctx *cx = calloc(1, sizeof(Ctx));
        uint64_t *hist = G_HIST + (size_t)wi * HIST_BINS;
        double next_ckpt = omp_get_wtime() + CKPT_EVERY;
        uint64_t w = W->cursor;
        uint64_t lbest_w = W->best_word; double lbest = W->best_pmax;
        int check = 0;

        while (w < W->band_end) {
            if (++check >= 256) {          /* cheap periodic checks */
                check = 0;
                W->cursor = w;
                if (G_STOP) break;
                if (t_deadline > 0 && omp_get_wtime() > t_deadline) break;
                if (wi == 0 && omp_get_wtime() >= next_ckpt) {
                    flush_all(ln, 0);
                    next_ckpt = omp_get_wtime() + CKPT_EVERY;
                }
            }
            DecOut o = screen_one(ln, st, C_SCREEN, cx, (uint32_t)w);
            W->seeds_done++;
            int bin = (int)(o.pmax * 100.0);
            if (bin < 0) bin = 0;
            if (bin >= HIST_BINS) bin = HIST_BINS - 1;
            hist[bin]++;
            if (o.pmax > lbest) {
                lbest = o.pmax; lbest_w = w;
                W->best_pmax = lbest; W->best_word = lbest_w;
            }
            if (G_NTOP < TOPK || o.pmax > G_TOP[0].pmax) {
                #pragma omp critical(topheap)
                heap_push(w, o.pmax);
            }
            if (o.pmax >= ln->cand_bar) {
                /* NEVER silently drop anything near the bar (SPEC section 0) */
                #pragma omp critical(candout)
                {
                    fprintf(G_CANDF, "{\"lane\": \"%s\", \"seed\": %llu, \"pmax\": %.17g}\n",
                            ln->name, (unsigned long long)w, o.pmax);
                    fflush(G_CANDF);
                    W->n_cand++;
                    if (o.pmax >= ln->claim_bar && G_NHITS < MAX_HITS) {
                        G_HITS[G_NHITS].seed = w; G_HITS[G_NHITS].pmax = o.pmax; G_NHITS++;
                        write_hits_file(ln);
                        printf("*** claim-bar candidate (KEEP SWEEPING): lane %s seed %llu "
                               "pmax %.9f >= %.9f -- FLAGGED-FOR-ORACLE pending Python "
                               "stage_b ***\n", ln->name, (unsigned long long)w, o.pmax,
                               ln->claim_bar);
                        fflush(stdout);
                    }
                }
            }
            w++;
        }
        W->cursor = w;
        if (w >= W->band_end) W->done = 1;
        free(cx);

        /* worker 0 keeps flushing while others still run */
        if (wi == 0) {
            for (;;) {
                int nd = 1;
                for (int i = 1; i < G_NW; i++)
                    if (!G_W[i].done && G_W[i].cursor < G_W[i].band_end) nd = 0;
                if (nd || G_STOP) break;
                if (t_deadline > 0 && omp_get_wtime() > t_deadline) break;
                struct timespec ts = {1, 0}; nanosleep(&ts, NULL);
                if (omp_get_wtime() >= next_ckpt) {
                    flush_all(ln, 0);
                    next_ckpt = omp_get_wtime() + CKPT_EVERY;
                }
            }
        }
    }

    alldone = 1;
    for (int i = 0; i < G_NW; i++) if (!G_W[i].done) alldone = 0;
    flush_all(ln, alldone);
    free(st);
    return alldone ? 0 : 1;
}

static int run_plan(const char *plan_path, double seconds) {
    long n;
    char *s = slurp(plan_path, &n);
    if (!s) die("cannot read sweep plan");
    Lane lanes[MAX_LANES]; int nl = 0;
    const char *pp = s, *os, *oe;
    while (nl < MAX_LANES && jnext_obj(&pp, s + n, &os, &oe)) {
        Lane *ln = &lanes[nl]; memset(ln, 0, sizeof *ln);
        char buf[64];
        if (!jstr(os, oe, "lane", ln->name, sizeof ln->name)) die("plan: lane name");
        if (!jstr(os, oe, "relation", buf, sizeof buf)) die("plan: relation");
        if (!strcmp(buf, "pair")) ln->pair = 1;
        else if (!strcmp(buf, "exact")) ln->pair = 0;
        else die("plan: relation must be 'pair' or 'exact'");
        if (!jstr(os, oe, "reducer", buf, sizeof buf)) die("plan: reducer");
        ln->reducer = reducer_from_name(buf);
        if (ln->reducer < 0) die("plan: unknown reducer");
        ln->offset = (int)jnum(os, oe, "offset", 0);
        ln->from = (uint64_t)jnum(os, oe, "from", 0);
        ln->to = (uint64_t)jnum(os, oe, "to", 4294967296.0);
        ln->cand_bar = jnum(os, oe, "cand_bar", 0);
        ln->claim_bar = jnum(os, oe, "claim_bar", 0);
        if (!jstr(os, oe, "gate", ln->gate, sizeof ln->gate)) ln->gate[0] = 0;
        lane_finish_init(ln);
        nl++;
    }
    free(s);
    if (!nl) die("empty sweep plan");
    snprintf(G_PLANPATH, sizeof G_PLANPATH, "%s", plan_path);

    /* completed-lane list from a previous STATUS.json */
    char p[1200]; snprintf(p, sizeof p, "%s/STATUS.json", G_RUNDIR);
    char *st = slurp(p, &n);
    if (st) {
        const char *la = jkey(st, st + n, "lanes_completed");
        if (la) {
            const char *q = la;
            while (q < st + n && *q != ']') {
                if (*q == '"') {
                    q++;
                    char nm[32]; int i = 0;
                    while (q < st + n && *q != '"' && i < 31) nm[i++] = *q++;
                    nm[i] = 0;
                    if (G_NDONE < MAX_LANES) strcpy(G_DONE_LANES[G_NDONE++], nm);
                }
                q++;
            }
        }
        free(st);
    }

    G_HIST = calloc((size_t)G_NW * HIST_BINS, sizeof(uint64_t));
    snprintf(p, sizeof p, "%s/candidates.jsonl", G_RUNDIR);
    G_CANDF = fopen(p, "a");
    if (!G_CANDF) die("cannot open candidates.jsonl for append");

    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);

    int rc = 0;
    for (int i = 0; i < nl; i++) {
        int skip = 0;
        for (int j = 0; j < G_NDONE; j++)
            if (!strcmp(G_DONE_LANES[j], lanes[i].name)) skip = 1;
        if (skip) { printf("lane %s already completed; skipping\n", lanes[i].name); continue; }
        /* grind28 STRUCTURAL GATE: no lane sweeps without its own passing per-cell
         * gate (PREREG Q1 (a)+(b)+(c)). There is deliberately NO override. */
        if (!lanes[i].gate[0]) {
            printf("REFUSING lane %s: no \"gate\" file named in the plan. Every "
                   "grind28 lane needs its per-cell gate (make_gates.py).\n",
                   lanes[i].name);
            rc = 1;
            break;
        }
        {
            Gate g;
            gate_load(lanes[i].gate, &g);
            if (strcmp(g.lane, lanes[i].name)
                || reducer_from_name(g.reducer) != lanes[i].reducer
                || g.offset != lanes[i].offset
                || (!strcmp(g.relation, "pair")) != lanes[i].pair) {
                printf("REFUSING lane %s: gate file %s describes a DIFFERENT cell "
                       "(%s/%s/o%d)\n", lanes[i].name, lanes[i].gate, g.lane,
                       g.reducer, g.offset);
                rc = 1;
                break;
            }
            if (gate_check(&g, 1)) {
                printf("REFUSING lane %s: per-cell gate FAILED -- an unvalidated "
                       "cell cannot produce a trustworthy null.\n", lanes[i].name);
                rc = 1;
                break;
            }
        }
        int r = run_lane(&lanes[i], seconds);
        if (r == 0) {
            if (G_NDONE < MAX_LANES) strcpy(G_DONE_LANES[G_NDONE++], lanes[i].name);
            write_status(&lanes[i], 1);
            printf("lane %s COMPLETE (coverage 1.0 of [%llu,%llu))\n", lanes[i].name,
                   (unsigned long long)lanes[i].from, (unsigned long long)lanes[i].to);
        } else {
            printf("lane %s interrupted (checkpointed; re-run to resume)\n", lanes[i].name);
            rc = 1;
            break;
        }
    }
    fclose(G_CANDF);
    return rc;
}

static int show_status(void) {
    char p[1200]; long n;
    snprintf(p, sizeof p, "%s/STATUS.json", G_RUNDIR);
    char *s = slurp(p, &n);
    if (!s) { printf("no STATUS.json in %s\n", G_RUNDIR); return 1; }
    fwrite(s, 1, (size_t)n, stdout);
    free(s);
    return 0;
}

/* ------------------------------------------------------------------ P2 ENGINE-CONTRACT modes
 * (score / sweep / self-test as specified in P2-harness/ENGINE-CONTRACT.md).
 * CRITICAL: StepTab is cipher-dependent -- any --cipher override rebuilds the step
 * tables (same lesson as the V2 planted screen). */

/* parse --cipher JSON {"cipher_idx": [...]}; fills C_out[LSCREEN] (first 120 entries) */
static void load_cipher_override(const char *path, int *C_out) {
    long n;
    char *s = slurp(path, &n);
    if (!s) die("cannot read --cipher file");
    const char *p = jkey(s, s + n, "cipher_idx");
    if (!p) die("--cipher file lacks \"cipher_idx\"");
    while (p < s + n && *p != '[') p++;
    if (p >= s + n) die("--cipher: cipher_idx is not an array");
    p++;
    int i = 0;
    while (i < LSCREEN && p < s + n) {
        while (p < s + n && (*p == ' ' || *p == ',' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
        if (p >= s + n || *p == ']') break;
        char *end;
        long v = strtol(p, &end, 10);
        if (end == p) die("--cipher: bad integer in cipher_idx");
        if (v < 0 || v >= NRUNE) die("--cipher: rune index out of [0,29)");
        C_out[i++] = (int)v;
        p = end;
    }
    free(s);
    if (i != LSCREEN) die("--cipher: need at least 120 cipher_idx entries");
}

/* --mode score: one u32/line in, one JSON object per line out, INPUT ORDER preserved */
static int mode_score(const char *seeds_path, const char *out_path, int full,
                      const int *cipher) {
    FILE *fi = fopen(seeds_path, "r");
    if (!fi) die("cannot open --seeds file");
    FILE *fo = fopen(out_path, "w");
    if (!fo) die("cannot open --out file");
    Lane ln = lane_S1();
    lane_apply_override(&ln);
    StepTab *st = calloc(LSCREEN, sizeof(StepTab));
    build_steps(cipher, st);
    Ctx *cx = calloc(1, sizeof(Ctx));
    char line[128];
    while (fgets(line, sizeof line, fi)) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\n' || *p == '\r' || !*p) continue;
        uint32_t w = (uint32_t)strtoull(p, NULL, 10);
        DecOut o = screen_one(&ln, st, cipher, cx, w);
        if (!full) {
            fprintf(fo, "{\"seed\": %u, \"pmax\": %.17g}\n", w, o.pmax);
        } else {
            fprintf(fo, "{\"seed\": %u, \"pmax\": %.17g, \"ks128\": [", w, o.pmax);
            for (int i = 0; i < 128; i++) fprintf(fo, "%s%d", i ? ", " : "", cx->Kx[i]);
            fprintf(fo, "], \"plain_idx\": [");
            for (int i = 0; i < LSCREEN; i++) fprintf(fo, "%s%d", i ? ", " : "", cx->plain[i]);
            fprintf(fo, "], \"ptr_end\": %d, \"n_skips\": %d, \"nchars\": %d}\n",
                    o.ptr_end, o.n_skips, o.nchars);
        }
    }
    fclose(fi); fclose(fo);
    free(cx); free(st);
    return 0;
}

/* --mode sweep: banded live sweep over [a,b); appends candidates >= cand_bar to out;
 * final stdout JSON summary. Same screen_one kernel + banding shape as run_lane. */
static int mode_sweep(uint64_t a, uint64_t b, int nthreads, const char *out_path,
                      const int *cipher, const char *progress_dir) {
    if (b <= a) die("--mode sweep: band-end must exceed band-start");
    Lane ln = lane_S1();
    lane_apply_override(&ln);
    StepTab *st = calloc(LSCREEN, sizeof(StepTab));
    build_steps(cipher, st);
    FILE *fo = fopen(out_path, "a");
    if (!fo) die("cannot open --out for append");
    static uint64_t wlo[MAX_WORKERS], whi[MAX_WORKERS], wdone[MAX_WORKERS],
                    wcand[MAX_WORKERS], wbw[MAX_WORKERS];
    static double wbest[MAX_WORKERS];
    const uint64_t total = b - a, step = total / (uint64_t)nthreads;
    for (int i = 0; i < nthreads; i++) {
        wlo[i] = a + (uint64_t)i * step;
        whi[i] = (i == nthreads - 1) ? b : a + (uint64_t)(i + 1) * step;
        wdone[i] = wcand[i] = wbw[i] = 0;
        wbest[i] = -1e30;
    }
    double t0 = omp_get_wtime();
    #pragma omp parallel num_threads(nthreads)
    {
        int wi = omp_get_thread_num();
        Ctx *cx = calloc(1, sizeof(Ctx));
        for (uint64_t w = wlo[wi]; w < whi[wi]; w++) {
            DecOut o = screen_one(&ln, st, cipher, cx, (uint32_t)w);
            wdone[wi]++;
            if (o.pmax > wbest[wi]) { wbest[wi] = o.pmax; wbw[wi] = w; }
            if (o.pmax >= ln.cand_bar) {
                wcand[wi]++;
                #pragma omp critical(sweepout)
                {
                    fprintf(fo, "{\"seed\": %llu, \"pmax\": %.17g}\n",
                            (unsigned long long)w, o.pmax);
                    fflush(fo);
                }
            }
        }
        free(cx);
    }
    double dt = omp_get_wtime() - t0;
    fclose(fo);
    uint64_t done = 0, ncand = 0;
    double best = -1e30; uint64_t bw = 0;
    for (int i = 0; i < nthreads; i++) {
        done += wdone[i]; ncand += wcand[i];
        if (wbest[i] > best) { best = wbest[i]; bw = wbw[i]; }
    }
    if (progress_dir) {                    /* SPEC section-6-compatible per-worker files */
        for (int i = 0; i < nthreads; i++) {
            char p[1200]; snprintf(p, sizeof p, "%s/progress_w%d.json", progress_dir, i);
            FILE *f = fopen(p, "w");
            if (!f) continue;
            fprintf(f, "{\"worker\": %d, \"band_start\": %llu, \"band_end\": %llu,"
                       " \"cursor\": %llu, \"seeds_done\": %llu, \"best_pmax\": %.17g,"
                       " \"best_word\": %llu, \"n_candidates\": %llu, \"done\": true}\n",
                    i, (unsigned long long)wlo[i], (unsigned long long)whi[i],
                    (unsigned long long)whi[i], (unsigned long long)wdone[i], wbest[i],
                    (unsigned long long)wbw[i], (unsigned long long)wcand[i]);
            fclose(f);
        }
    }
    printf("{\"mode\": \"sweep\", \"seeds_done\": %llu, \"elapsed_s\": %.3f,"
           " \"band_start\": %llu, \"band_end\": %llu, \"threads\": %d,"
           " \"n_candidates\": %llu, \"best_pmax\": %.17g, \"best_word\": %llu}\n",
           (unsigned long long)done, dt, (unsigned long long)a, (unsigned long long)b,
           nthreads, (unsigned long long)ncand, best, (unsigned long long)bw);
    free(st);
    return 0;
}

/* ------------------------------------------------------------------ main */
int main(int argc, char **argv) {
    int do_selftest = 0, do_drill = 0, do_status = 0;
    uint64_t bench_n = 0;
    const char *plan = NULL;
    double seconds = 0;
    char dat_path[1200];

    /* engine.dat lives next to the binary's source dir by convention; allow override */
    snprintf(dat_path, sizeof dat_path, "engine.dat");
    {   /* prefer engine.dat next to the executable */
        char exe[1024]; ssize_t r = readlink("/proc/self/exe", exe, sizeof exe - 1);
        if (r > 0) {
            exe[r] = 0;
            char *sl = strrchr(exe, '/');
            if (sl) { *sl = 0; snprintf(dat_path, sizeof dat_path, "%s/engine.dat", exe); }
        }
    }

    /* P2 ENGINE-CONTRACT flags (P2-harness/ENGINE-CONTRACT.md) */
    const char *mode = NULL, *seeds_path = NULL, *out_path = NULL;
    const char *cipher_path = NULL, *progress_dir = NULL, *gate_path = NULL;
    int full = 0;
    uint64_t band_start = 0, band_end = 0;
    int have_bs = 0, have_be = 0;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--self-test")) do_selftest = 1;
        else if (!strcmp(argv[i], "--drill")) do_drill = 1;
        else if (!strcmp(argv[i], "--status")) do_status = 1;
        else if (!strcmp(argv[i], "--bench") && i + 1 < argc) bench_n = strtoull(argv[++i], NULL, 10);
        else if (!strcmp(argv[i], "--plan") && i + 1 < argc) plan = argv[++i];
        else if (!strcmp(argv[i], "--run-dir") && i + 1 < argc)
            snprintf(G_RUNDIR, sizeof G_RUNDIR, "%s", argv[++i]);
        else if (!strcmp(argv[i], "--seconds") && i + 1 < argc) seconds = atof(argv[++i]);
        else if (!strcmp(argv[i], "--threads") && i + 1 < argc) G_NW = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--data") && i + 1 < argc)
            snprintf(dat_path, sizeof dat_path, "%s", argv[++i]);
        /* -- contract flags -- */
        else if (!strcmp(argv[i], "--vectors") && i + 1 < argc) i++;   /* accepted; engine
            loads the identical data via engine.dat (exported FROM vectors.json) */
        else if (!strcmp(argv[i], "--lm") && i + 1 < argc) i++;        /* ditto (sha256 of
            panel_lm.f32 is verified against panel.npz by check_vectors) */
        else if (!strcmp(argv[i], "--mode") && i + 1 < argc) mode = argv[++i];
        else if (!strcmp(argv[i], "--seeds") && i + 1 < argc) seeds_path = argv[++i];
        else if (!strcmp(argv[i], "--out") && i + 1 < argc) out_path = argv[++i];
        else if (!strcmp(argv[i], "--full")) full = 1;
        else if (!strcmp(argv[i], "--cipher") && i + 1 < argc) cipher_path = argv[++i];
        else if (!strcmp(argv[i], "--band-start") && i + 1 < argc)
            { band_start = strtoull(argv[++i], NULL, 10); have_bs = 1; }
        else if (!strcmp(argv[i], "--band-end") && i + 1 < argc)
            { band_end = strtoull(argv[++i], NULL, 10); have_be = 1; }
        else if (!strcmp(argv[i], "--progress-dir") && i + 1 < argc) progress_dir = argv[++i];
        /* -- grind28 flags -- */
        else if (!strcmp(argv[i], "--gate-check") && i + 1 < argc) gate_path = argv[++i];
        else if (!strcmp(argv[i], "--reducer") && i + 1 < argc) {
            G_OV_REDUCER = reducer_from_name(argv[++i]);
            if (G_OV_REDUCER < 0) die("--reducer: unknown name");
        }
        else if (!strcmp(argv[i], "--relation") && i + 1 < argc) {
            const char *r = argv[++i];
            if (!strcmp(r, "pair")) G_OV_PAIR = 1;
            else if (!strcmp(r, "exact")) G_OV_PAIR = 0;
            else die("--relation must be pair|exact");
        }
        else if (!strcmp(argv[i], "--offset") && i + 1 < argc) G_OV_OFFSET = atoi(argv[++i]);
        else { fprintf(stderr, "unknown arg %s\n", argv[i]); return 1; }
    }
    if (G_NW < 1 || G_NW > MAX_WORKERS) die("--threads out of range");

    if (do_status) return show_status();

    init_tables();
    load_engine_dat(dat_path);
    load_quadgrams();
    load_panel();

    if (mode) {                            /* ---- P2 ENGINE-CONTRACT dispatch ---- */
        int cipher[LSCREEN];
        memcpy(cipher, C_SCREEN, sizeof cipher);
        if (cipher_path) load_cipher_override(cipher_path, cipher);
        if (!strcmp(mode, "self-test")) {
            DecOut o;
            memset(&o, 0, sizeof o);
            int st_rc = self_test(&o);     /* full V1+V2 (K3-grade), plant DecOut out */
            int cand = o.pmax >= G_CAND_BAR;
            printf("{\"mode\": \"self-test\", \"seed\": %d, \"pmax\": %.17g,"
                   " \"candidate\": %s}\n", G_PLANT_SEED, o.pmax, cand ? "true" : "false");
            return (st_rc == 0 && cand) ? 0 : 1;
        }
        if (!strcmp(mode, "score")) {
            if (!seeds_path || !out_path) die("--mode score needs --seeds and --out");
            return mode_score(seeds_path, out_path, full, cipher);
        }
        if (!strcmp(mode, "sweep")) {
            if (!out_path || !have_bs || !have_be)
                die("--mode sweep needs --band-start, --band-end and --out");
            return mode_sweep(band_start, band_end, G_NW, out_path, cipher, progress_dir);
        }
        fprintf(stderr, "unknown --mode %s (score|sweep|self-test)\n", mode);
        return 1;
    }

    if (gate_path) {                       /* ---- grind28 per-cell gate runner ---- */
        Gate g;
        gate_load(gate_path, &g);
        return gate_check(&g, 1);
    }
    if (do_selftest) return self_test(NULL);
    if (do_drill) {
        if (self_test(NULL)) { printf("refusing drill: self-test failed\n"); return 1; }
        return drill();
    }
    if (bench_n) return bench(bench_n, G_NW);
    if (plan) {
        /* K3 (PREREG): planted screen control must pass at every launch/restart */
        if (self_test(NULL)) { printf("ABORT: self-test failed; broken scan, not a null\n"); return 1; }
        return run_plan(plan, seconds);
    }
    fprintf(stderr, "usage: grind28 --self-test | --drill | "
                    "--gate-check gates/cellgate_X.dat | "
                    "--bench N [--reducer R --relation pair|exact --offset O] | "
                    "--plan queued_cells.json --run-dir DIR [--seconds S] [--threads N] | "
                    "--status --run-dir DIR | "
                    "--mode score|sweep|self-test [contract flags per "
                    "round27/P2-harness/ENGINE-CONTRACT.md; --reducer/--relation/"
                    "--offset override the cell]\n");
    return 1;
}
